<!-- meta tags and other links -->
<!DOCTYPE html>
<html lang="en" data-theme="light">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="description"
    content="Modern Education Admin Dashboard for schools, colleges, universities, and eLearning platforms. Includes student and course management, attendance, exams, payments, analytics, and a fully responsive clean UI—ideal for LMS, coaching centers, and academic admin systems.">
  <meta name="keywords"
    content="Education Admin Dashboard, School Admin Panel, College Dashboard, University Dashboard, LMS Dashboard, eLearning Admin Template, Student Management System, Course Management, Education Template, Study Dashboard, Online Learning Dashboard, Academic Admin Panel, Bootstrap Dashboard, React Education Dashboard, Next.js Education Template">
  <meta name="robots" content="INDEX,FOLLOW">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Title -->
  <title>Edudash - School, College & LMS Admin Dashboard Template | Bootstrap 5</title>
  <link rel="icon" type="image/png" href="assets/images/favicon.png" sizes="16x16">
  <!-- remix icon font css  -->
  <link rel="stylesheet" href="assets/css/remixicon.css">
  <!-- BootStrap css -->
  <link rel="stylesheet" href="assets/css/lib/bootstrap.min.css">
  <!-- Apex Chart css -->
  <link rel="stylesheet" href="assets/css/lib/apexcharts.css">
  <!-- Data Table css -->
  <link rel="stylesheet" href="assets/css/lib/dataTables.min.css">
  <!-- Date picker css -->
  <link rel="stylesheet" href="assets/css/lib/flatpickr.min.css">
  <!-- Calendar css -->
  <link rel="stylesheet" href="assets/css/lib/full-calendar.css">
  <!-- calendar -->
  <link rel="stylesheet" href="assets/css/lib/calendar.css">
  <!-- main css -->
  <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

  <!-- Theme Customization Structure Start -->
<div class="body-overlay"></div>

<button type="button"
    class="theme-customization__button w-48-px h-48-px bg-primary-600 text-white rounded-circle d-flex justify-content-center align-items-center position-fixed end-0 bottom-0 mb-40 me-40 text-2xxl bg-hover-primary-700" aria-label="Theme Customization Button">
    <i class="ri-settings-3-line animate-spin"></i>
</button>
<div class="theme-customization-sidebar w-100 bg-base h-100vh overflow-y-auto position-fixed end-0 top-0">
    <div class="d-flex align-items-center gap-3 py-16 px-24 justify-content-between border-bottom">
        <div>
            <h6 class="text-sm dark:text-white">Theme Settings</h6>
            <p class="text-xs mb-0 text-neutral-500 dark:text-neutral-200">Customize and preview instantly</p>
        </div>
        <button data-slot="button"
            class="theme-customization-sidebar__close text-neutral-900 bg-transparent text-hover-primary-600 d-flex text-xl">
            <i class="ri-close-fill"></i>
        </button>
    </div>

    <div class="d-flex flex-column gap-48 p-24 overflow-y-auto flex-grow-1">

        <div class="theme-setting-item">
            <h6 class="fw-medium text-primary-light text-md mb-3">Theme Mode</h6>
            <div class="d-grid grid-cols-3 gap-3 dark-light-mode">
                <button type="button"
                    class="theme-btn theme-setting-item__btn d-flex align-items-center justify-content-center h-64-px rounded-3 text-xl active"
                    data-theme="light" aria-label="light">
                    <i class="ri-sun-line"></i>
                </button>
                <button type="button"
                    class="theme-btn theme-setting-item__btn d-flex align-items-center justify-content-center h-64-px rounded-3 text-xl"
                    data-theme="dark" aria-label="dark">
                    <i class="ri-moon-line"></i>
                </button>
                <button type="button"
                    class="theme-btn theme-setting-item__btn d-flex align-items-center justify-content-center h-64-px rounded-3 text-xl"
                    data-theme="system" aria-label="system">
                    <i class="ri-computer-line"></i>
                </button>
            </div>
        </div>

        <div class="theme-setting-item">
            <h6 class="fw-medium text-primary-light text-md mb-3">Page Direction</h6>
            <div class="d-grid grid-cols-2 gap-3">
                <button type="button"
                    class="theme-setting-item__btn ltr-mode-btn d-flex align-items-center justify-content-center gap-2 h-56-px rounded-3 text-xl" aria-label="LTR">
                    <span><i class="ri-align-item-left-line"></i></span>
                    <span class="h6 text-sm font-medium mb-0">LTR</span>
                </button>

                <button type="button"
                    class="theme-setting-item__btn rtl-mode-btn d-flex align-items-center justify-content-center gap-2 h-56-px rounded-3 text-xl" aria-label="RTL">
                    <span class="h6 text-sm font-medium mb-0">RTL</span>
                    <span><i class="ri-align-item-right-line"></i></span>
                </button>
            </div>
        </div>

        <div class="theme-setting-item">
            <h6 class="fw-medium text-primary-light text-md mb-3">Color Schema</h6>
            <div class="d-grid grid-cols-3 gap-3">
                <button type="button"
                    class="color-picker-btn d-flex flex-column justify-content-center align-items-center"
                    data-color="base" aria-label="Base">
                    <span class="color-picker-btn__box h-40-px w-100 rounded-3"
                        style="background-color: #25A194;"></span>
                    <span class="fw-medium mt-1" style="color: #25A194;">Base</span>
                </button>
                <button type="button"
                    class="color-picker-btn d-flex flex-column justify-content-center align-items-center"
                    data-color="red" aria-label="Red">
                    <span class="color-picker-btn__box h-40-px w-100 rounded-3"
                        style="background-color: #dc2626;"></span>
                    <span class="fw-medium mt-1" style="color: #dc2626;">Red</span>
                </button>
                <button type="button"
                    class="color-picker-btn d-flex flex-column justify-content-center align-items-center"
                    data-color="blue" aria-label="Blue">
                    <span class="color-picker-btn__box h-40-px w-100 rounded-3"
                        style="background-color: #2563eb;"></span>
                    <span class="fw-medium mt-1" style="color: #2563eb;">Blue</span>
                </button>
                <button type="button"
                    class="color-picker-btn d-flex flex-column justify-content-center align-items-center"
                    data-color="yellow" aria-label="Yellow">
                    <span class="color-picker-btn__box h-40-px w-100 rounded-3"
                        style="background-color: #ff9f29;"></span>
                    <span class="fw-medium mt-1" style="color: #ff9f29;">Yellow</span>
                </button>
                <button type="button"
                    class="color-picker-btn d-flex flex-column justify-content-center align-items-center"
                    data-color="cyan" aria-label="Cyan">
                    <span class="color-picker-btn__box h-40-px w-100 rounded-3"
                        style="background-color: #00b8f2;"></span>
                    <span class="fw-medium mt-1" style="color: #00b8f2;">Cyan</span>
                </button>
                <button type="button"
                    class="color-picker-btn d-flex flex-column justify-content-center align-items-center"
                    data-color="violet" aria-label="Violet">
                    <span class="color-picker-btn__box h-40-px w-100 rounded-3"
                        style="background-color: #7c3aed;"></span>
                    <span class="fw-medium mt-1" style="color: #7c3aed;">Violet</span>
                </button>
            </div>
        </div>

    </div>
</div>
<!-- Theme Customization Structure End -->

  <div class="overlay bg-black bg-opacity-50 w-100 h-100 position-fixed z-9 visibility-hidden opacity-0 duration-300">
  </div>
<aside class="sidebar">
  <button type="button" class="sidebar-close-btn">
    <iconify-icon icon="radix-icons:cross-2"></iconify-icon>
  </button>
  <div class="">
    <div class="sidebar-logo d-flex align-items-center justify-content-between">
      <a href="index.php" class="">
        <img src="assets/images/logo.png" alt="site logo" class="light-logo">
        <img src="assets/images/logo-light.png" alt="site logo" class="dark-logo">
        <img src="assets/images/logo-icon.png" alt="site logo" class="logo-icon">
      </a>
      <button type="button" class="text-xxl d-xl-flex d-none line-height-1 sidebar-toggle text-neutral-500"
        aria-label="Collapse Sidebar">
        <i class="ri-contract-left-line"></i>
      </button>
    </div>
  </div>
  <!-- User Info start -->
  <div class="mx-16 py-12">
    <div class="dropdown profile-dropdown">
      <button type="button"
        class="profile-dropdown__button d-flex align-items-center justify-content-between p-10 w-100 overflow-hidden bg-neutral-50 radius-12 "
        data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false">
        <span class="d-flex align-items-start gap-10">
          <img src="assets/images/thumbs/leave-request-img2.png" alt="Thumbnail"
            class="w-40-px h-40-px rounded-circle object-fit-cover flex-shrink-0">
          <span class="profile-dropdown__contents">
            <span class="h6 mb-0 text-md d-block text-primary-light">Jone Copper</span>
            <span class="text-secondary-light text-sm mb-0 d-block">Admin</span>
          </span>
        </span>
        <span class="profile-dropdown__icon pe-8 text-xl d-flex line-height-1">
          <i class="ri-arrow-right-s-line"></i>
        </span>
      </button>
      <ul class="dropdown-menu dropdown-menu-lg-end border p-12">
        <li>
          <a href="student-details.php" 
            class="dropdown-item rounded text-secondary-light bg-hover-neutral-200 text-hover-neutral-900 d-flex align-items-center gap-2 py-6">
            <i class="ri-user-3-line"></i>
            My Profile
          </a>
        </li>
        <li>
          <a href="general.php"
            class="dropdown-item rounded text-secondary-light bg-hover-neutral-200 text-hover-neutral-900 d-flex align-items-center gap-2 py-6">
            <i class="ri-settings-3-line"></i>
            Setting
          </a>
        </li>
        <li>
          <a href="login.php"
            class="dropdown-item rounded text-secondary-light bg-hover-neutral-200 text-hover-neutral-900 d-flex align-items-center gap-2 py-6">
            <i class="ri-shut-down-line"></i>
            Log Out
          </a>
        </li>
      </ul>
    </div>
  </div>
  <!-- User Info end -->
  <div class="sidebar-menu-area">
    <ul class="sidebar-menu" id="sidebar-menu">
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-home-4-line"></i>
          <span>Dashboard </span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="index.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              School
            </a>
          </li>
          <li>
            <a href="index-2.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Student
            </a>
          </li>
          <li>
            <a href="index-3.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Teacher
            </a>
          </li>
          <li>
            <a href="index-4.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Parent
            </a>
          </li>
          <li>
            <a href="index-5.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              LMS 
            </a>
          </li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-graduation-cap-line"></i>
          <span>Students</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="add-new-student.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Add New Student
            </a>
          </li>
          <li>
            <a href="student-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Student List
            </a>
          </li>
          <li>
            <a href="suspended-student.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Suspend Student
            </a>
          </li>
          <li>
            <a href="student-category.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Student Categories
            </a>
          </li>
          <li>
            <a href="edit-student.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Edit Student
            </a>
          </li>
          <li>
            <a href="student-details.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Student Details
            </a>
          </li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-user-follow-line"></i>
          <span>Teachers</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="add-new-teacher.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Add New Teacher
            </a>
          </li>
          <li>
            <a href="teacher-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Teacher List
            </a>
          </li>
          <li>
            <a href="edit-teacher.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Edit Teacher
            </a>
          </li>
          <li>
            <a href="teacher-details.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Teacher Details
            </a>
          </li>
          <li>
            <a href="teacher-timetable.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Teacher Timetable
            </a>
          </li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-account-circle-line"></i>
          <span>Guardian</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="add-new-guardian.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Add New Guardians
            </a>
          </li>
          <li>
            <a href="guardian-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Guardians List
            </a>
          </li>
          <li>
            <a href="edit-guardian.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Edit Guardian
            </a>
          </li>
          <li>
            <a href="guardian-details.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Guardian Details
            </a>
          </li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-list-view"></i>
          <span>Classes</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="section-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Section
            </a>
          </li>
          <li>
            <a href="subject-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Subjects
            </a>
          </li>
          <li>
            <a href="class-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Class List
            </a>
          </li>
          <li>
            <a href="class-room-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Class Room
            </a>
          </li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-file-edit-line"></i>
          <span>Examinations</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="exam.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Exam
            </a>
          </li>
          <li>
            <a href="exam-schedule.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Exam Schedule
            </a>
          </li>
          <li>
            <a href="exam-result.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Exam Result
            </a>
          </li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-money-dollar-circle-line"></i>
          <span>Fees Collection</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="fees-collect.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Fees Collect
            </a>
          </li>
          <li>
            <a href="fees-type.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Fees Type
            </a>
          </li>
          <li>
            <a href="fees-group.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Fees Group
            </a>
          </li>
          <li>
            <a href="fees-discount.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Fees Discount
            </a>
          </li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-calendar-check-line"></i>
          <span>Attendance</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="student-attendance.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Student Attendance
            </a>
          </li>
          <li>
            <a href="teacher-attendance.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Teacher Attendance
            </a>
          </li>
          <li>
            <a href="employee-attendance.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Employee Attendance
            </a>
          </li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-time-line"></i>
          <span>Leaves</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="leave-types.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Leave Types
            </a>
          </li>
          <li>
            <a href="leave-request.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Leave Request
            </a>
          </li>
        </ul>
      </li>
      <li>
        <a href="certificate.php">
          <i class="ri-home-4-line"></i>
          <span>Certificate </span>
        </a>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-book-2-line"></i>
          <span>Library</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="books-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Books List
            </a>
          </li>
          <li>
            <a href="members-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Members List
            </a>
          </li>
          <li>
            <a href="member-details.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Members Details
            </a>
          </li>
          <li>
            <a href="issue-return.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Issue Return
            </a>
          </li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-money-dollar-circle-line"></i>
          <span>Accounts</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="income-head.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Income Head
            </a>
          </li>
          <li>
            <a href="income-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Income List
            </a>
          </li>
          <li>
            <a href="expense-head.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Expense Head
            </a>
          </li>
          <li>
            <a href="expense-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Expense List
            </a>
          </li>
          <li>
            <a href="transaction.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Transaction
            </a>
          </li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-user-settings-line"></i>
          <span>HRM</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="employee-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Employee List
            </a>
          </li>
          <li>
            <a href="employee-details.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Employee Details
            </a>
          </li>
          <li>
            <a href="add-new-employee.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Add New Employee
            </a>
          </li>
          <li>
            <a href="payroll.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Payroll
            </a>
          </li>
          <li>
            <a href="designation.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Designation
            </a>
          <li>
            <a href="department.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Department
            </a>
          </li>
        </ul>
      </li>
      <li>
        <a href="notice-board.php">
          <i class="ri-booklet-line"></i>
          <span>Notice Board </span>
        </a>
      </li>
      <li>
        <a href="event.php">
          <i class="ri-calendar-event-line"></i>
          <span>Event </span>
        </a>
      </li>
      <li>
        <a href="message.php">
          <i class="ri-message-2-line"></i>
          <span>Message </span>
        </a>
      </li>
      <li>
        <a href="subscription-plan.php">
          <i class="ri-price-tag-3-line"></i>
          <span>Subscription Plan </span>
        </a>
      </li>
      <li>
        <a href="role-access.php">
          <i class="ri-macbook-line"></i>
          <span>Role & Access</span>
        </a>
      </li>
         <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-shield-check-line"></i>
          <span>Authentication</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="login.php"><i class="ri-circle-fill circle-icon text-primary-600 w-auto"></i> Login</a>
          </li>
          <li>
            <a href="register.php"><i class="ri-circle-fill circle-icon text-warning-main w-auto"></i> Register</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="assign-role-plan.php">
          <i class="ri-user-follow-line"></i>
          <span>Assign Role</span>
        </a>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-user-settings-line"></i>
          <span>Settings</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="general.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              General
            </a>
          </li>
          <li>
            <a href="notification.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Notification
            </a>
          </li>
          <li>
            <a href="currencies.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Currencies
            </a>
          </li>
          <li>
            <a href="languages.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Languages
            </a>
          </li>
        </ul>
      </li>
    </ul>
  </div>
</aside>

<main class="dashboard-main">
    <div class="navbar-header shadow-1">
  <div class="row align-items-center justify-content-between">
    <div class="col-auto">
      <div class="d-flex flex-wrap align-items-center gap-4">
        <button type="button" class="sidebar-mobile-toggle" aria-label="Sidebar Mobile Toggler Button">
          <iconify-icon icon="heroicons:bars-3-solid" class="icon"></iconify-icon>
        </button>
        <form class="navbar-search">
          <input type="text" class="bg-transparent" name="search" placeholder="Search">
          <iconify-icon icon="ion:search-outline" class="icon"></iconify-icon>
        </form>
      </div>
    </div>
    <div class="col-auto">
      <div class="d-flex flex-wrap align-items-center gap-3">
        <button type="button" data-theme-toggle
          class="w-40-px h-40-px bg-neutral-200 rounded-circle d-flex justify-content-center align-items-center" aria-label="Dark & Light Mode Button"></button>
        <div class="dropdown d-inline-block">
          <button
            class="has-indicator w-40-px h-40-px bg-neutral-200 rounded-circle d-flex justify-content-center align-items-center"
            type="button" data-bs-toggle="dropdown" aria-label="Language Change Button">
            <img src="assets/images/flags/flag1.png" alt="image" class="w-24 h-24 object-fit-cover rounded-circle">
          </button>
          <div class="dropdown-menu to-top dropdown-menu-sm">
            <div
              class="py-12 px-16 radius-8 bg-primary-50 mb-16 d-flex align-items-center justify-content-between gap-2">
              <div>
                <h6 class="text-lg text-primary-light fw-semibold mb-0">Choose Your Language</h6>
              </div>
            </div>

            <div class="max-h-400-px overflow-y-auto scroll-sm pe-8">
              <div class="form-check style-check d-flex align-items-center justify-content-between mb-16">
                <label class="form-check-label line-height-1 fw-medium text-secondary-light" for="english">
                  <span class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                    <img src="assets/images/flags/flag1.png" alt="Image"
                      class="w-36-px h-36-px bg-success-subtle text-success-main rounded-circle flex-shrink-0">
                    <span class="text-md fw-semibold mb-0">English</span>
                  </span>
                </label>
                <input class="form-check-input" type="radio" name="crypto" id="english">
              </div>

              <div class="form-check style-check d-flex align-items-center justify-content-between mb-16">
                <label class="form-check-label line-height-1 fw-medium text-secondary-light" for="japan">
                  <span class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                    <img src="assets/images/flags/flag2.png" alt="Image"
                      class="w-36-px h-36-px bg-success-subtle text-success-main rounded-circle flex-shrink-0">
                    <span class="text-md fw-semibold mb-0">Japan</span>
                  </span>
                </label>
                <input class="form-check-input" type="radio" name="crypto" id="japan">
              </div>

              <div class="form-check style-check d-flex align-items-center justify-content-between mb-16">
                <label class="form-check-label line-height-1 fw-medium text-secondary-light" for="france">
                  <span class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                    <img src="assets/images/flags/flag3.png" alt="Image"
                      class="w-36-px h-36-px bg-success-subtle text-success-main rounded-circle flex-shrink-0">
                    <span class="text-md fw-semibold mb-0">France</span>
                  </span>
                </label>
                <input class="form-check-input" type="radio" name="crypto" id="france">
              </div>

              <div class="form-check style-check d-flex align-items-center justify-content-between mb-16">
                <label class="form-check-label line-height-1 fw-medium text-secondary-light" for="germany">
                  <span class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                    <img src="assets/images/flags/flag4.png" alt="Image"
                      class="w-36-px h-36-px bg-success-subtle text-success-main rounded-circle flex-shrink-0">
                    <span class="text-md fw-semibold mb-0">Germany</span>
                  </span>
                </label>
                <input class="form-check-input" type="radio" name="crypto" id="germany">
              </div>

              <div class="form-check style-check d-flex align-items-center justify-content-between mb-16">
                <label class="form-check-label line-height-1 fw-medium text-secondary-light" for="korea">
                  <span class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                    <img src="assets/images/flags/flag5.png" alt="Image"
                      class="w-36-px h-36-px bg-success-subtle text-success-main rounded-circle flex-shrink-0">
                    <span class="text-md fw-semibold mb-0">South Korea</span>
                  </span>
                </label>
                <input class="form-check-input" type="radio" name="crypto" id="korea">
              </div>

              <div class="form-check style-check d-flex align-items-center justify-content-between mb-16">
                <label class="form-check-label line-height-1 fw-medium text-secondary-light" for="bangladesh">
                  <span class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                    <img src="assets/images/flags/flag6.png" alt="Image"
                      class="w-36-px h-36-px bg-success-subtle text-success-main rounded-circle flex-shrink-0">
                    <span class="text-md fw-semibold mb-0">Bangladesh</span>
                  </span>
                </label>
                <input class="form-check-input" type="radio" name="crypto" id="bangladesh">
              </div>

              <div class="form-check style-check d-flex align-items-center justify-content-between mb-16">
                <label class="form-check-label line-height-1 fw-medium text-secondary-light" for="india">
                  <span class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                    <img src="assets/images/flags/flag7.png" alt="Image"
                      class="w-36-px h-36-px bg-success-subtle text-success-main rounded-circle flex-shrink-0">
                    <span class="text-md fw-semibold mb-0">India</span>
                  </span>
                </label>
                <input class="form-check-input" type="radio" name="crypto" id="india">
              </div>
              <div class="form-check style-check d-flex align-items-center justify-content-between">
                <label class="form-check-label line-height-1 fw-medium text-secondary-light" for="canada">
                  <span class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                    <img src="assets/images/flags/flag8.png" alt="Image"
                      class="w-36-px h-36-px bg-success-subtle text-success-main rounded-circle flex-shrink-0">
                    <span class="text-md fw-semibold mb-0">Canada</span>
                  </span>
                </label>
                <input class="form-check-input" type="radio" name="crypto" id="canada">
              </div>
            </div>
          </div>
        </div><!-- Language dropdown end -->

        <div class="dropdown">
          <button
            class="has-indicator w-40-px h-40-px bg-neutral-200 rounded-circle d-flex justify-content-center align-items-center position-relative"
            type="button" data-bs-toggle="dropdown" aria-label="Notification Button">
            <iconify-icon icon="iconoir:bell" class="text-primary-light text-xl"></iconify-icon>
            <span class="w-8-px h-8-px bg-danger-600 position-absolute end-0 top-0 rounded-circle mt-2 me-2"></span>
          </button>
          <div class="dropdown-menu to-top dropdown-menu-lg p-0">
            <div
              class="m-16 py-12 px-16 radius-8 bg-primary-50 mb-16 d-flex align-items-center justify-content-between gap-2">
              <div>
                <h6 class="text-lg text-primary-light fw-semibold mb-0">Notifications</h6>
              </div>
              <span
                class="text-primary-600 fw-semibold text-lg w-40-px h-40-px rounded-circle bg-base d-flex justify-content-center align-items-center">05</span>
            </div>

            <div class="max-h-400-px overflow-y-auto scroll-sm pe-4">
              <a href="javascript:void(0)"
                class="px-24 py-12 d-flex align-items-start gap-3 mb-2 justify-content-between">
                <div class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                  <span
                    class="w-44-px h-44-px bg-success-subtle text-success-main rounded-circle d-flex justify-content-center align-items-center flex-shrink-0">
                    <iconify-icon icon="bitcoin-icons:verify-outline" class="icon text-xxl"></iconify-icon>
                  </span>
                  <div>
                    <h6 class="text-md fw-semibold mb-4">Congratulations</h6>
                    <p class="mb-0 text-sm text-secondary-light text-w-200-px">Your profile has been Verified. Your
                      profile has been Verified</p>
                  </div>
                </div>
                <span class="text-sm text-secondary-light flex-shrink-0">23 Mins ago</span>
              </a>

              <a href="javascript:void(0)"
                class="px-24 py-12 d-flex align-items-start gap-3 mb-2 justify-content-between bg-neutral-50">
                <div class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                  <span
                    class="w-44-px h-44-px bg-success-subtle text-success-main rounded-circle d-flex justify-content-center align-items-center flex-shrink-0">
                    <img src="assets/images/notification/profile-1.png" alt="Image">
                  </span>
                  <div>
                    <h6 class="text-md fw-semibold mb-4">Ronald Richards</h6>
                    <p class="mb-0 text-sm text-secondary-light text-w-200-px">You can stitch between artboards</p>
                  </div>
                </div>
                <span class="text-sm text-secondary-light flex-shrink-0">23 Mins ago</span>
              </a>

              <a href="javascript:void(0)"
                class="px-24 py-12 d-flex align-items-start gap-3 mb-2 justify-content-between">
                <div class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                  <span
                    class="w-44-px h-44-px bg-info-subtle text-info-main rounded-circle d-flex justify-content-center align-items-center flex-shrink-0">
                    AM
                  </span>
                  <div>
                    <h6 class="text-md fw-semibold mb-4">Arlene McCoy</h6>
                    <p class="mb-0 text-sm text-secondary-light text-w-200-px">Invite you to prototyping</p>
                  </div>
                </div>
                <span class="text-sm text-secondary-light flex-shrink-0">23 Mins ago</span>
              </a>

              <a href="javascript:void(0)"
                class="px-24 py-12 d-flex align-items-start gap-3 mb-2 justify-content-between bg-neutral-50">
                <div class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                  <span
                    class="w-44-px h-44-px bg-success-subtle text-success-main rounded-circle d-flex justify-content-center align-items-center flex-shrink-0">
                    <img src="assets/images/notification/profile-2.png" alt="Image">
                  </span>
                  <div>
                    <h6 class="text-md fw-semibold mb-4">Robiul Hasan</h6>
                    <p class="mb-0 text-sm text-secondary-light text-w-200-px">Invite you to prototyping</p>
                  </div>
                </div>
                <span class="text-sm text-secondary-light flex-shrink-0">23 Mins ago</span>
              </a>

              <a href="javascript:void(0)"
                class="px-24 py-12 d-flex align-items-start gap-3 mb-2 justify-content-between">
                <div class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                  <span
                    class="w-44-px h-44-px bg-info-subtle text-info-main rounded-circle d-flex justify-content-center align-items-center flex-shrink-0">
                    DR
                  </span>
                  <div>
                    <h6 class="text-md fw-semibold mb-4">Darlene Robertson</h6>
                    <p class="mb-0 text-sm text-secondary-light text-w-200-px">Invite you to prototyping</p>
                  </div>
                </div>
                <span class="text-sm text-secondary-light flex-shrink-0">23 Mins ago</span>
              </a>
            </div>

            <div class="text-center py-12 px-16">
              <a href="javascript:void(0)" class="text-primary-600 fw-semibold text-md hover-underline">See All Notification</a>
            </div>

          </div>
        </div><!-- Notification dropdown end -->

      </div>
    </div>
  </div>
</div>

    <div class="dashboard-main-body">

        <div class="breadcrumb d-flex flex-wrap align-items-center justify-content-between gap-3 mb-24">
            <div class="">
                <h1 class="fw-semibold mb-4 h6 text-primary-light">Subscription Plan </h1>
                <div class="">
                    <a href="index.php" class="text-secondary-light hover-text-primary hover-underline">Dashboard </a>
                    <span class="text-secondary-light">/ Subscription Plan</span>
                </div>
            </div>
        </div>

        <div class="mt-24">
            <div class="card h-100 p-0 radius-12 overflow-hidden mt-24">
                <div class="card-body p-40">
                    <div class="row justify-content-center">
                        <div class="col-xxl-10">
                            <div class="text-center">
                                <h4 class="mb-0">Simple, Transparent Pricing</h4>
                            </div>

                            <div class="pricing-tab">
                                <div
                                    class="form-switch switch-primary d-flex align-items-center gap-3 mt-28 justify-content-center">
                                    <label class="form-check-label line-height-1 fw-medium text-secondary-light"
                                        for="yes">Monthly</label>
                                    <input class="form-check-input choose-plan-input" type="checkbox" role="switch"
                                        id="yes">
                                    <label class="form-check-label line-height-1 fw-medium text-secondary-light"
                                        for="yes">Annually</label>
                                </div>
                            </div>

                            <div class="row gy-4">
                                <div class="col-xxl-4 col-sm-6">
                                    <div
                                        class="pricing-plan position-relative radius-24 overflow-hidden border bg-base">
                                        <div class="d-flex align-items-center gap-16">
                                            <span
                                                class="w-72-px h-72-px d-flex justify-content-center align-items-center radius-16 bg-primary-50">
                                                <img src="assets/images/icons/price-icon1.png" alt="Image">
                                            </span>
                                            <div class="">
                                                <span class="fw-medium text-md text-secondary-light">For
                                                    individuals</span>
                                                <h6 class="mb-0">Basic</h6>
                                            </div>
                                        </div>
                                        <p class="mt-16 mb-0 text-secondary-light mb-28">Lorem ipsum dolor sit amet
                                            doloroli sitiol conse ctetur adipiscing elit. </p>
                                        <h3 class="mb-24">
                                            $<span class="price-range">99</span>
                                            <span class="fw-medium text-md text-secondary-light">/monthly</span>
                                        </h3>
                                        <span class="mb-20 fw-medium">What's included</span>
                                        <ul>
                                            <li class="d-flex align-items-center gap-16 mb-16">
                                                <span
                                                    class="w-24-px h-24-px d-flex justify-content-center align-items-center bg-primary-600 rounded-circle"><iconify-icon
                                                        icon="iconamoon:check-light"
                                                        class="text-white text-lg "></iconify-icon></span>
                                                <span class="text-secondary-light text-lg">All analytics features</span>
                                            </li>
                                            <li class="d-flex align-items-center gap-16 mb-16">
                                                <span
                                                    class="w-24-px h-24-px d-flex justify-content-center align-items-center bg-primary-600 rounded-circle"><iconify-icon
                                                        icon="iconamoon:check-light"
                                                        class="text-white text-lg "></iconify-icon></span>
                                                <span class="text-secondary-light text-lg">Up to 250,000 tracked
                                                    visits</span>
                                            </li>
                                            <li class="d-flex align-items-center gap-16 mb-16">
                                                <span
                                                    class="w-24-px h-24-px d-flex justify-content-center align-items-center bg-primary-600 rounded-circle"><iconify-icon
                                                        icon="iconamoon:check-light"
                                                        class="text-white text-lg "></iconify-icon></span>
                                                <span class="text-secondary-light text-lg">Normal support</span>
                                            </li>
                                            <li class="d-flex align-items-center gap-16">
                                                <span
                                                    class="w-24-px h-24-px d-flex justify-content-center align-items-center bg-primary-600 rounded-circle"><iconify-icon
                                                        icon="iconamoon:check-light"
                                                        class="text-white text-lg "></iconify-icon></span>
                                                <span class="text-secondary-light text-lg">Up to 3 team members</span>
                                            </li>
                                        </ul>
                                        <button type="button"
                                            class="bg-primary-600 bg-hover-primary-700 text-white text-center border border-primary-600 text-sm btn-sm px-12 py-10 w-100 radius-8 mt-28"
                                            data-bs-toggle="modal" data-bs-target="#exampleModal">Get started</button>
                                    </div>
                                </div>
                                <div class="col-xxl-4 col-sm-6">
                                    <div
                                        class="pricing-plan featured-item position-relative radius-24 overflow-hidden border bg-primary-600 text-white z-1">
                                        <img src="assets/images/icons/pricing-shape.png" alt="Image"
                                            class="position-absolute end-0 top-10 z-n1">
                                        <span
                                            class="bg-white bg-opacity-25 text-white radius-24 py-8 px-24 text-sm position-absolute end-0 top-0 z-1 rounded-start-top-0 rounded-end-bottom-0">Popular</span>
                                        <div class="d-flex align-items-center gap-16">
                                            <span
                                                class="w-72-px h-72-px d-flex justify-content-center align-items-center radius-16 bg-base">
                                                <img src="assets/images/icons/price-icon2.png" alt="Image">
                                            </span>
                                            <div class="">
                                                <span class="fw-medium text-md text-white">For startups</span>
                                                <h6 class="mb-0 text-white">Pro</h6>
                                            </div>
                                        </div>
                                        <p class="mt-16 mb-0 text-white mb-28">Lorem ipsum dolor sit amet doloroli
                                            sitiol conse ctetur adipiscing elit. </p>
                                        <h3 class="mb-24 text-white">
                                            $<span class="price-range">199</span>
                                            <span class="fw-medium text-md text-white">/monthly</span>
                                        </h3>
                                        <span class="mb-20 fw-medium">What's included</span>
                                        <ul>
                                            <li class="d-flex align-items-center gap-16 mb-16">
                                                <span
                                                    class="w-24-px h-24-px d-flex justify-content-center align-items-center bg-white rounded-circle text-primary-600"><iconify-icon
                                                        icon="iconamoon:check-light"
                                                        class="text-lg   "></iconify-icon></span>
                                                <span class="text-white text-lg">All analytics features</span>
                                            </li>
                                            <li class="d-flex align-items-center gap-16 mb-16">
                                                <span
                                                    class="w-24-px h-24-px d-flex justify-content-center align-items-center bg-white rounded-circle text-primary-600"><iconify-icon
                                                        icon="iconamoon:check-light"
                                                        class="text-lg   "></iconify-icon></span>
                                                <span class="text-white text-lg">Up to 250,000 tracked visits</span>
                                            </li>
                                            <li class="d-flex align-items-center gap-16 mb-16">
                                                <span
                                                    class="w-24-px h-24-px d-flex justify-content-center align-items-center bg-white rounded-circle text-primary-600"><iconify-icon
                                                        icon="iconamoon:check-light"
                                                        class="text-lg   "></iconify-icon></span>
                                                <span class="text-white text-lg">Normal support</span>
                                            </li>
                                            <li class="d-flex align-items-center gap-16">
                                                <span
                                                    class="w-24-px h-24-px d-flex justify-content-center align-items-center bg-white rounded-circle text-primary-600"><iconify-icon
                                                        icon="iconamoon:check-light"
                                                        class="text-lg   "></iconify-icon></span>
                                                <span class="text-white text-lg">Up to 3 team members</span>
                                            </li>
                                        </ul>
                                        <button type="button"
                                            class="bg-white text-primary-600 text-white text-center border border-white text-sm btn-sm px-12 py-10 w-100 radius-8 mt-28"
                                            data-bs-toggle="modal" data-bs-target="#exampleModal">Get started</button>

                                    </div>
                                </div>
                                <div class="col-xxl-4 col-sm-6">
                                    <div
                                        class="pricing-plan position-relative radius-24 overflow-hidden border bg-base">
                                        <div class="d-flex align-items-center gap-16">
                                            <span
                                                class="w-72-px h-72-px d-flex justify-content-center align-items-center radius-16 bg-primary-50">
                                                <img src="assets/images/icons/price-icon3.png" alt="Image">
                                            </span>
                                            <div class="">
                                                <span class="fw-medium text-md text-secondary-light">For big
                                                    companies</span>
                                                <h6 class="mb-0">Enterprise</h6>
                                            </div>
                                        </div>
                                        <p class="mt-16 mb-0 text-secondary-light mb-28">Lorem ipsum dolor sit amet
                                            doloroli sitiol conse ctetur adipiscing elit. </p>
                                        <h3 class="mb-24">
                                            $<span class="price-range">399</span>
                                            <span class="fw-medium text-md text-secondary-light">/monthly</span>
                                        </h3>
                                        <span class="mb-20 fw-medium">What's included</span>
                                        <ul>
                                            <li class="d-flex align-items-center gap-16 mb-16">
                                                <span
                                                    class="w-24-px h-24-px d-flex justify-content-center align-items-center bg-primary-600 rounded-circle"><iconify-icon
                                                        icon="iconamoon:check-light"
                                                        class="text-white text-lg "></iconify-icon></span>
                                                <span class="text-secondary-light text-lg">All analytics features</span>
                                            </li>
                                            <li class="d-flex align-items-center gap-16 mb-16">
                                                <span
                                                    class="w-24-px h-24-px d-flex justify-content-center align-items-center bg-primary-600 rounded-circle"><iconify-icon
                                                        icon="iconamoon:check-light"
                                                        class="text-white text-lg "></iconify-icon></span>
                                                <span class="text-secondary-light text-lg">Up to 250,000 tracked
                                                    visits</span>
                                            </li>
                                            <li class="d-flex align-items-center gap-16 mb-16">
                                                <span
                                                    class="w-24-px h-24-px d-flex justify-content-center align-items-center bg-primary-600 rounded-circle"><iconify-icon
                                                        icon="iconamoon:check-light"
                                                        class="text-white text-lg "></iconify-icon></span>
                                                <span class="text-secondary-light text-lg">Normal support</span>
                                            </li>
                                            <li class="d-flex align-items-center gap-16">
                                                <span
                                                    class="w-24-px h-24-px d-flex justify-content-center align-items-center bg-primary-600 rounded-circle"><iconify-icon
                                                        icon="iconamoon:check-light"
                                                        class="text-white text-lg "></iconify-icon></span>
                                                <span class="text-secondary-light text-lg">Up to 3 team members</span>
                                            </li>
                                        </ul>
                                        <button type="button"
                                            class="bg-primary-600 bg-hover-primary-700 text-white text-center border border-primary-600 text-sm btn-sm px-12 py-10 w-100 radius-8 mt-28"
                                            data-bs-toggle="modal" data-bs-target="#exampleModal">Get started</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="d-footer">
  <div class="">
    <p class="mb-0 text-center"> &copy; <span class="current-year"></span> Made With ❤️ by Wowtheme7.</p>
  </div>
</footer>
</main>

  <!-- jQuery library js -->
  <script src="assets/js/lib/jquery-3.7.1.min.js"></script>
  <!-- Bootstrap js -->
  <script src="assets/js/lib/bootstrap.bundle.min.js"></script>
  <!-- Apex Chart js -->
  <script src="assets/js/lib/apexcharts.min.js"></script>
  <!-- Iconify Font js -->
  <script src="assets/js/lib/iconify-icon.min.js"></script>
  <!-- Data Table js -->
  <script src="assets/js/lib/dataTables.min.js"></script>
  
  <!-- jQuery UI js -->
  <script src="assets/js/lib/jquery-ui.min.js"></script>
  
  <!-- main js -->
  <script src="assets/js/app.js"></script>

<script>
    let choosePlanInput = document.querySelector('.choose-plan-input');
    let priceRanges = document.querySelectorAll('.price-range');

    // Store original prices (once)
    priceRanges.forEach(price => {
        price.dataset.original = price.innerHTML.trim();
    });

    choosePlanInput.addEventListener('change', function () {

        if (this.checked) {
            // When checked → Multiply by 10
            priceRanges.forEach(price => {
                let cleanValue = price.dataset.original.replace(/[^0-9.]/g, '').trim();
                let multiplied = Number(cleanValue) * 10;
                price.innerHTML = multiplied;
            });

        } else {
            // When unchecked → Restore original values
            priceRanges.forEach(price => {
                price.innerHTML = price.dataset.original;
            });
        }
    });
</script>

</body>

</html>