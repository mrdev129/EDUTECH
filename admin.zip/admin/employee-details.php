<!-- meta tags and other links -->
<!DOCTYPE html>
<html lang="en" data-theme="light">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="description"
    content="Modern Education Admin Dashboard for schools, colleges, universities, and eLearning platforms. Includes student and course management, attendance, exams, payments, analytics, and a fully responsive clean UI—ideal for LMS, coaching centers, and academic admin systems.">
  <meta name="keywords"
    content="Education Admin Dashboard, School Admin Panel, College Dashboard, University Dashboard, LMS Dashboard, eLearning Admin Template, Student Management System, Course Management, Education Template, Study Dashboard, Online Learning Dashboard, Academic Admin Panel, Bootstrap Dashboard, React Education Dashboard, Next.js Education Template">
  <meta name="robots" content="INDEX,FOLLOW">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Title -->
  <title>Edudash - School, College & LMS Admin Dashboard Template | Bootstrap 5</title>
  <link rel="icon" type="image/png" href="assets/images/favicon.png" sizes="16x16">
  <!-- remix icon font css  -->
  <link rel="stylesheet" href="assets/css/remixicon.css">
  <!-- BootStrap css -->
  <link rel="stylesheet" href="assets/css/lib/bootstrap.min.css">
  <!-- Apex Chart css -->
  <link rel="stylesheet" href="assets/css/lib/apexcharts.css">
  <!-- Data Table css -->
  <link rel="stylesheet" href="assets/css/lib/dataTables.min.css">
  <!-- Date picker css -->
  <link rel="stylesheet" href="assets/css/lib/flatpickr.min.css">
  <!-- Calendar css -->
  <link rel="stylesheet" href="assets/css/lib/full-calendar.css">
  <!-- calendar -->
  <link rel="stylesheet" href="assets/css/lib/calendar.css">
  <!-- main css -->
  <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

  <!-- Theme Customization Structure Start -->
<div class="body-overlay"></div>

<button type="button"
    class="theme-customization__button w-48-px h-48-px bg-primary-600 text-white rounded-circle d-flex justify-content-center align-items-center position-fixed end-0 bottom-0 mb-40 me-40 text-2xxl bg-hover-primary-700" aria-label="Theme Customization Button">
    <i class="ri-settings-3-line animate-spin"></i>
</button>
<div class="theme-customization-sidebar w-100 bg-base h-100vh overflow-y-auto position-fixed end-0 top-0">
    <div class="d-flex align-items-center gap-3 py-16 px-24 justify-content-between border-bottom">
        <div>
            <h6 class="text-sm dark:text-white">Theme Settings</h6>
            <p class="text-xs mb-0 text-neutral-500 dark:text-neutral-200">Customize and preview instantly</p>
        </div>
        <button data-slot="button"
            class="theme-customization-sidebar__close text-neutral-900 bg-transparent text-hover-primary-600 d-flex text-xl">
            <i class="ri-close-fill"></i>
        </button>
    </div>

    <div class="d-flex flex-column gap-48 p-24 overflow-y-auto flex-grow-1">

        <div class="theme-setting-item">
            <h6 class="fw-medium text-primary-light text-md mb-3">Theme Mode</h6>
            <div class="d-grid grid-cols-3 gap-3 dark-light-mode">
                <button type="button"
                    class="theme-btn theme-setting-item__btn d-flex align-items-center justify-content-center h-64-px rounded-3 text-xl active"
                    data-theme="light" aria-label="light">
                    <i class="ri-sun-line"></i>
                </button>
                <button type="button"
                    class="theme-btn theme-setting-item__btn d-flex align-items-center justify-content-center h-64-px rounded-3 text-xl"
                    data-theme="dark" aria-label="dark">
                    <i class="ri-moon-line"></i>
                </button>
                <button type="button"
                    class="theme-btn theme-setting-item__btn d-flex align-items-center justify-content-center h-64-px rounded-3 text-xl"
                    data-theme="system" aria-label="system">
                    <i class="ri-computer-line"></i>
                </button>
            </div>
        </div>

        <div class="theme-setting-item">
            <h6 class="fw-medium text-primary-light text-md mb-3">Page Direction</h6>
            <div class="d-grid grid-cols-2 gap-3">
                <button type="button"
                    class="theme-setting-item__btn ltr-mode-btn d-flex align-items-center justify-content-center gap-2 h-56-px rounded-3 text-xl" aria-label="LTR">
                    <span><i class="ri-align-item-left-line"></i></span>
                    <span class="h6 text-sm font-medium mb-0">LTR</span>
                </button>

                <button type="button"
                    class="theme-setting-item__btn rtl-mode-btn d-flex align-items-center justify-content-center gap-2 h-56-px rounded-3 text-xl" aria-label="RTL">
                    <span class="h6 text-sm font-medium mb-0">RTL</span>
                    <span><i class="ri-align-item-right-line"></i></span>
                </button>
            </div>
        </div>

        <div class="theme-setting-item">
            <h6 class="fw-medium text-primary-light text-md mb-3">Color Schema</h6>
            <div class="d-grid grid-cols-3 gap-3">
                <button type="button"
                    class="color-picker-btn d-flex flex-column justify-content-center align-items-center"
                    data-color="base" aria-label="Base">
                    <span class="color-picker-btn__box h-40-px w-100 rounded-3"
                        style="background-color: #25A194;"></span>
                    <span class="fw-medium mt-1" style="color: #25A194;">Base</span>
                </button>
                <button type="button"
                    class="color-picker-btn d-flex flex-column justify-content-center align-items-center"
                    data-color="red" aria-label="Red">
                    <span class="color-picker-btn__box h-40-px w-100 rounded-3"
                        style="background-color: #dc2626;"></span>
                    <span class="fw-medium mt-1" style="color: #dc2626;">Red</span>
                </button>
                <button type="button"
                    class="color-picker-btn d-flex flex-column justify-content-center align-items-center"
                    data-color="blue" aria-label="Blue">
                    <span class="color-picker-btn__box h-40-px w-100 rounded-3"
                        style="background-color: #2563eb;"></span>
                    <span class="fw-medium mt-1" style="color: #2563eb;">Blue</span>
                </button>
                <button type="button"
                    class="color-picker-btn d-flex flex-column justify-content-center align-items-center"
                    data-color="yellow" aria-label="Yellow">
                    <span class="color-picker-btn__box h-40-px w-100 rounded-3"
                        style="background-color: #ff9f29;"></span>
                    <span class="fw-medium mt-1" style="color: #ff9f29;">Yellow</span>
                </button>
                <button type="button"
                    class="color-picker-btn d-flex flex-column justify-content-center align-items-center"
                    data-color="cyan" aria-label="Cyan">
                    <span class="color-picker-btn__box h-40-px w-100 rounded-3"
                        style="background-color: #00b8f2;"></span>
                    <span class="fw-medium mt-1" style="color: #00b8f2;">Cyan</span>
                </button>
                <button type="button"
                    class="color-picker-btn d-flex flex-column justify-content-center align-items-center"
                    data-color="violet" aria-label="Violet">
                    <span class="color-picker-btn__box h-40-px w-100 rounded-3"
                        style="background-color: #7c3aed;"></span>
                    <span class="fw-medium mt-1" style="color: #7c3aed;">Violet</span>
                </button>
            </div>
        </div>

    </div>
</div>
<!-- Theme Customization Structure End -->

  <div class="overlay bg-black bg-opacity-50 w-100 h-100 position-fixed z-9 visibility-hidden opacity-0 duration-300">
  </div>
<aside class="sidebar">
  <button type="button" class="sidebar-close-btn">
    <iconify-icon icon="radix-icons:cross-2"></iconify-icon>
  </button>
  <div class="">
    <div class="sidebar-logo d-flex align-items-center justify-content-between">
      <a href="index.php" class="">
        <img src="assets/images/logo.png" alt="site logo" class="light-logo">
        <img src="assets/images/logo-light.png" alt="site logo" class="dark-logo">
        <img src="assets/images/logo-icon.png" alt="site logo" class="logo-icon">
      </a>
      <button type="button" class="text-xxl d-xl-flex d-none line-height-1 sidebar-toggle text-neutral-500"
        aria-label="Collapse Sidebar">
        <i class="ri-contract-left-line"></i>
      </button>
    </div>
  </div>
  <!-- User Info start -->
  <div class="mx-16 py-12">
    <div class="dropdown profile-dropdown">
      <button type="button"
        class="profile-dropdown__button d-flex align-items-center justify-content-between p-10 w-100 overflow-hidden bg-neutral-50 radius-12 "
        data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false">
        <span class="d-flex align-items-start gap-10">
          <img src="assets/images/thumbs/leave-request-img2.png" alt="Thumbnail"
            class="w-40-px h-40-px rounded-circle object-fit-cover flex-shrink-0">
          <span class="profile-dropdown__contents">
            <span class="h6 mb-0 text-md d-block text-primary-light">Jone Copper</span>
            <span class="text-secondary-light text-sm mb-0 d-block">Admin</span>
          </span>
        </span>
        <span class="profile-dropdown__icon pe-8 text-xl d-flex line-height-1">
          <i class="ri-arrow-right-s-line"></i>
        </span>
      </button>
      <ul class="dropdown-menu dropdown-menu-lg-end border p-12">
        <li>
          <a href="student-details.php" 
            class="dropdown-item rounded text-secondary-light bg-hover-neutral-200 text-hover-neutral-900 d-flex align-items-center gap-2 py-6">
            <i class="ri-user-3-line"></i>
            My Profile
          </a>
        </li>
        <li>
          <a href="general.php"
            class="dropdown-item rounded text-secondary-light bg-hover-neutral-200 text-hover-neutral-900 d-flex align-items-center gap-2 py-6">
            <i class="ri-settings-3-line"></i>
            Setting
          </a>
        </li>
        <li>
          <a href="login.php"
            class="dropdown-item rounded text-secondary-light bg-hover-neutral-200 text-hover-neutral-900 d-flex align-items-center gap-2 py-6">
            <i class="ri-shut-down-line"></i>
            Log Out
          </a>
        </li>
      </ul>
    </div>
  </div>
  <!-- User Info end -->
  <div class="sidebar-menu-area">
    <ul class="sidebar-menu" id="sidebar-menu">
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-home-4-line"></i>
          <span>Dashboard </span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="index.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              School
            </a>
          </li>
          <li>
            <a href="index-2.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Student
            </a>
          </li>
          <li>
            <a href="index-3.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Teacher
            </a>
          </li>
          <li>
            <a href="index-4.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Parent
            </a>
          </li>
          <li>
            <a href="index-5.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              LMS 
            </a>
          </li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-graduation-cap-line"></i>
          <span>Students</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="add-new-student.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Add New Student
            </a>
          </li>
          <li>
            <a href="student-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Student List
            </a>
          </li>
          <li>
            <a href="suspended-student.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Suspend Student
            </a>
          </li>
          <li>
            <a href="student-category.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Student Categories
            </a>
          </li>
          <li>
            <a href="edit-student.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Edit Student
            </a>
          </li>
          <li>
            <a href="student-details.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Student Details
            </a>
          </li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-user-follow-line"></i>
          <span>Teachers</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="add-new-teacher.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Add New Teacher
            </a>
          </li>
          <li>
            <a href="teacher-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Teacher List
            </a>
          </li>
          <li>
            <a href="edit-teacher.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Edit Teacher
            </a>
          </li>
          <li>
            <a href="teacher-details.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Teacher Details
            </a>
          </li>
          <li>
            <a href="teacher-timetable.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Teacher Timetable
            </a>
          </li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-account-circle-line"></i>
          <span>Guardian</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="add-new-guardian.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Add New Guardians
            </a>
          </li>
          <li>
            <a href="guardian-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Guardians List
            </a>
          </li>
          <li>
            <a href="edit-guardian.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Edit Guardian
            </a>
          </li>
          <li>
            <a href="guardian-details.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Guardian Details
            </a>
          </li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-list-view"></i>
          <span>Classes</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="section-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Section
            </a>
          </li>
          <li>
            <a href="subject-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Subjects
            </a>
          </li>
          <li>
            <a href="class-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Class List
            </a>
          </li>
          <li>
            <a href="class-room-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Class Room
            </a>
          </li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-file-edit-line"></i>
          <span>Examinations</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="exam.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Exam
            </a>
          </li>
          <li>
            <a href="exam-schedule.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Exam Schedule
            </a>
          </li>
          <li>
            <a href="exam-result.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Exam Result
            </a>
          </li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-money-dollar-circle-line"></i>
          <span>Fees Collection</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="fees-collect.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Fees Collect
            </a>
          </li>
          <li>
            <a href="fees-type.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Fees Type
            </a>
          </li>
          <li>
            <a href="fees-group.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Fees Group
            </a>
          </li>
          <li>
            <a href="fees-discount.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Fees Discount
            </a>
          </li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-calendar-check-line"></i>
          <span>Attendance</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="student-attendance.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Student Attendance
            </a>
          </li>
          <li>
            <a href="teacher-attendance.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Teacher Attendance
            </a>
          </li>
          <li>
            <a href="employee-attendance.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Employee Attendance
            </a>
          </li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-time-line"></i>
          <span>Leaves</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="leave-types.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Leave Types
            </a>
          </li>
          <li>
            <a href="leave-request.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Leave Request
            </a>
          </li>
        </ul>
      </li>
      <li>
        <a href="certificate.php">
          <i class="ri-home-4-line"></i>
          <span>Certificate </span>
        </a>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-book-2-line"></i>
          <span>Library</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="books-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Books List
            </a>
          </li>
          <li>
            <a href="members-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Members List
            </a>
          </li>
          <li>
            <a href="member-details.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Members Details
            </a>
          </li>
          <li>
            <a href="issue-return.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Issue Return
            </a>
          </li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-money-dollar-circle-line"></i>
          <span>Accounts</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="income-head.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Income Head
            </a>
          </li>
          <li>
            <a href="income-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Income List
            </a>
          </li>
          <li>
            <a href="expense-head.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Expense Head
            </a>
          </li>
          <li>
            <a href="expense-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Expense List
            </a>
          </li>
          <li>
            <a href="transaction.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Transaction
            </a>
          </li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-user-settings-line"></i>
          <span>HRM</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="employee-list.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Employee List
            </a>
          </li>
          <li>
            <a href="employee-details.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Employee Details
            </a>
          </li>
          <li>
            <a href="add-new-employee.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Add New Employee
            </a>
          </li>
          <li>
            <a href="payroll.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Payroll
            </a>
          </li>
          <li>
            <a href="designation.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Designation
            </a>
          <li>
            <a href="department.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Department
            </a>
          </li>
        </ul>
      </li>
      <li>
        <a href="notice-board.php">
          <i class="ri-booklet-line"></i>
          <span>Notice Board </span>
        </a>
      </li>
      <li>
        <a href="event.php">
          <i class="ri-calendar-event-line"></i>
          <span>Event </span>
        </a>
      </li>
      <li>
        <a href="message.php">
          <i class="ri-message-2-line"></i>
          <span>Message </span>
        </a>
      </li>
      <li>
        <a href="subscription-plan.php">
          <i class="ri-price-tag-3-line"></i>
          <span>Subscription Plan </span>
        </a>
      </li>
      <li>
        <a href="role-access.php">
          <i class="ri-macbook-line"></i>
          <span>Role & Access</span>
        </a>
      </li>
         <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-shield-check-line"></i>
          <span>Authentication</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="login.php"><i class="ri-circle-fill circle-icon text-primary-600 w-auto"></i> Login</a>
          </li>
          <li>
            <a href="register.php"><i class="ri-circle-fill circle-icon text-warning-main w-auto"></i> Register</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="assign-role-plan.php">
          <i class="ri-user-follow-line"></i>
          <span>Assign Role</span>
        </a>
      </li>
      <li class="dropdown">
        <a href="javascript:void(0)">
          <i class="ri-user-settings-line"></i>
          <span>Settings</span>
        </a>
        <ul class="sidebar-submenu">
          <li>
            <a href="general.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              General
            </a>
          </li>
          <li>
            <a href="notification.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Notification
            </a>
          </li>
          <li>
            <a href="currencies.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Currencies
            </a>
          </li>
          <li>
            <a href="languages.php">
              <i class="ri-circle-fill circle-icon w-auto"></i>
              Languages
            </a>
          </li>
        </ul>
      </li>
    </ul>
  </div>
</aside>

<main class="dashboard-main">
    <div class="navbar-header shadow-1">
  <div class="row align-items-center justify-content-between">
    <div class="col-auto">
      <div class="d-flex flex-wrap align-items-center gap-4">
        <button type="button" class="sidebar-mobile-toggle" aria-label="Sidebar Mobile Toggler Button">
          <iconify-icon icon="heroicons:bars-3-solid" class="icon"></iconify-icon>
        </button>
        <form class="navbar-search">
          <input type="text" class="bg-transparent" name="search" placeholder="Search">
          <iconify-icon icon="ion:search-outline" class="icon"></iconify-icon>
        </form>
      </div>
    </div>
    <div class="col-auto">
      <div class="d-flex flex-wrap align-items-center gap-3">
        <button type="button" data-theme-toggle
          class="w-40-px h-40-px bg-neutral-200 rounded-circle d-flex justify-content-center align-items-center" aria-label="Dark & Light Mode Button"></button>
        <div class="dropdown d-inline-block">
          <button
            class="has-indicator w-40-px h-40-px bg-neutral-200 rounded-circle d-flex justify-content-center align-items-center"
            type="button" data-bs-toggle="dropdown" aria-label="Language Change Button">
            <img src="assets/images/flags/flag1.png" alt="image" class="w-24 h-24 object-fit-cover rounded-circle">
          </button>
          <div class="dropdown-menu to-top dropdown-menu-sm">
            <div
              class="py-12 px-16 radius-8 bg-primary-50 mb-16 d-flex align-items-center justify-content-between gap-2">
              <div>
                <h6 class="text-lg text-primary-light fw-semibold mb-0">Choose Your Language</h6>
              </div>
            </div>

            <div class="max-h-400-px overflow-y-auto scroll-sm pe-8">
              <div class="form-check style-check d-flex align-items-center justify-content-between mb-16">
                <label class="form-check-label line-height-1 fw-medium text-secondary-light" for="english">
                  <span class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                    <img src="assets/images/flags/flag1.png" alt="Image"
                      class="w-36-px h-36-px bg-success-subtle text-success-main rounded-circle flex-shrink-0">
                    <span class="text-md fw-semibold mb-0">English</span>
                  </span>
                </label>
                <input class="form-check-input" type="radio" name="crypto" id="english">
              </div>

              <div class="form-check style-check d-flex align-items-center justify-content-between mb-16">
                <label class="form-check-label line-height-1 fw-medium text-secondary-light" for="japan">
                  <span class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                    <img src="assets/images/flags/flag2.png" alt="Image"
                      class="w-36-px h-36-px bg-success-subtle text-success-main rounded-circle flex-shrink-0">
                    <span class="text-md fw-semibold mb-0">Japan</span>
                  </span>
                </label>
                <input class="form-check-input" type="radio" name="crypto" id="japan">
              </div>

              <div class="form-check style-check d-flex align-items-center justify-content-between mb-16">
                <label class="form-check-label line-height-1 fw-medium text-secondary-light" for="france">
                  <span class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                    <img src="assets/images/flags/flag3.png" alt="Image"
                      class="w-36-px h-36-px bg-success-subtle text-success-main rounded-circle flex-shrink-0">
                    <span class="text-md fw-semibold mb-0">France</span>
                  </span>
                </label>
                <input class="form-check-input" type="radio" name="crypto" id="france">
              </div>

              <div class="form-check style-check d-flex align-items-center justify-content-between mb-16">
                <label class="form-check-label line-height-1 fw-medium text-secondary-light" for="germany">
                  <span class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                    <img src="assets/images/flags/flag4.png" alt="Image"
                      class="w-36-px h-36-px bg-success-subtle text-success-main rounded-circle flex-shrink-0">
                    <span class="text-md fw-semibold mb-0">Germany</span>
                  </span>
                </label>
                <input class="form-check-input" type="radio" name="crypto" id="germany">
              </div>

              <div class="form-check style-check d-flex align-items-center justify-content-between mb-16">
                <label class="form-check-label line-height-1 fw-medium text-secondary-light" for="korea">
                  <span class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                    <img src="assets/images/flags/flag5.png" alt="Image"
                      class="w-36-px h-36-px bg-success-subtle text-success-main rounded-circle flex-shrink-0">
                    <span class="text-md fw-semibold mb-0">South Korea</span>
                  </span>
                </label>
                <input class="form-check-input" type="radio" name="crypto" id="korea">
              </div>

              <div class="form-check style-check d-flex align-items-center justify-content-between mb-16">
                <label class="form-check-label line-height-1 fw-medium text-secondary-light" for="bangladesh">
                  <span class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                    <img src="assets/images/flags/flag6.png" alt="Image"
                      class="w-36-px h-36-px bg-success-subtle text-success-main rounded-circle flex-shrink-0">
                    <span class="text-md fw-semibold mb-0">Bangladesh</span>
                  </span>
                </label>
                <input class="form-check-input" type="radio" name="crypto" id="bangladesh">
              </div>

              <div class="form-check style-check d-flex align-items-center justify-content-between mb-16">
                <label class="form-check-label line-height-1 fw-medium text-secondary-light" for="india">
                  <span class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                    <img src="assets/images/flags/flag7.png" alt="Image"
                      class="w-36-px h-36-px bg-success-subtle text-success-main rounded-circle flex-shrink-0">
                    <span class="text-md fw-semibold mb-0">India</span>
                  </span>
                </label>
                <input class="form-check-input" type="radio" name="crypto" id="india">
              </div>
              <div class="form-check style-check d-flex align-items-center justify-content-between">
                <label class="form-check-label line-height-1 fw-medium text-secondary-light" for="canada">
                  <span class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                    <img src="assets/images/flags/flag8.png" alt="Image"
                      class="w-36-px h-36-px bg-success-subtle text-success-main rounded-circle flex-shrink-0">
                    <span class="text-md fw-semibold mb-0">Canada</span>
                  </span>
                </label>
                <input class="form-check-input" type="radio" name="crypto" id="canada">
              </div>
            </div>
          </div>
        </div><!-- Language dropdown end -->

        <div class="dropdown">
          <button
            class="has-indicator w-40-px h-40-px bg-neutral-200 rounded-circle d-flex justify-content-center align-items-center position-relative"
            type="button" data-bs-toggle="dropdown" aria-label="Notification Button">
            <iconify-icon icon="iconoir:bell" class="text-primary-light text-xl"></iconify-icon>
            <span class="w-8-px h-8-px bg-danger-600 position-absolute end-0 top-0 rounded-circle mt-2 me-2"></span>
          </button>
          <div class="dropdown-menu to-top dropdown-menu-lg p-0">
            <div
              class="m-16 py-12 px-16 radius-8 bg-primary-50 mb-16 d-flex align-items-center justify-content-between gap-2">
              <div>
                <h6 class="text-lg text-primary-light fw-semibold mb-0">Notifications</h6>
              </div>
              <span
                class="text-primary-600 fw-semibold text-lg w-40-px h-40-px rounded-circle bg-base d-flex justify-content-center align-items-center">05</span>
            </div>

            <div class="max-h-400-px overflow-y-auto scroll-sm pe-4">
              <a href="javascript:void(0)"
                class="px-24 py-12 d-flex align-items-start gap-3 mb-2 justify-content-between">
                <div class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                  <span
                    class="w-44-px h-44-px bg-success-subtle text-success-main rounded-circle d-flex justify-content-center align-items-center flex-shrink-0">
                    <iconify-icon icon="bitcoin-icons:verify-outline" class="icon text-xxl"></iconify-icon>
                  </span>
                  <div>
                    <h6 class="text-md fw-semibold mb-4">Congratulations</h6>
                    <p class="mb-0 text-sm text-secondary-light text-w-200-px">Your profile has been Verified. Your
                      profile has been Verified</p>
                  </div>
                </div>
                <span class="text-sm text-secondary-light flex-shrink-0">23 Mins ago</span>
              </a>

              <a href="javascript:void(0)"
                class="px-24 py-12 d-flex align-items-start gap-3 mb-2 justify-content-between bg-neutral-50">
                <div class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                  <span
                    class="w-44-px h-44-px bg-success-subtle text-success-main rounded-circle d-flex justify-content-center align-items-center flex-shrink-0">
                    <img src="assets/images/notification/profile-1.png" alt="Image">
                  </span>
                  <div>
                    <h6 class="text-md fw-semibold mb-4">Ronald Richards</h6>
                    <p class="mb-0 text-sm text-secondary-light text-w-200-px">You can stitch between artboards</p>
                  </div>
                </div>
                <span class="text-sm text-secondary-light flex-shrink-0">23 Mins ago</span>
              </a>

              <a href="javascript:void(0)"
                class="px-24 py-12 d-flex align-items-start gap-3 mb-2 justify-content-between">
                <div class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                  <span
                    class="w-44-px h-44-px bg-info-subtle text-info-main rounded-circle d-flex justify-content-center align-items-center flex-shrink-0">
                    AM
                  </span>
                  <div>
                    <h6 class="text-md fw-semibold mb-4">Arlene McCoy</h6>
                    <p class="mb-0 text-sm text-secondary-light text-w-200-px">Invite you to prototyping</p>
                  </div>
                </div>
                <span class="text-sm text-secondary-light flex-shrink-0">23 Mins ago</span>
              </a>

              <a href="javascript:void(0)"
                class="px-24 py-12 d-flex align-items-start gap-3 mb-2 justify-content-between bg-neutral-50">
                <div class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                  <span
                    class="w-44-px h-44-px bg-success-subtle text-success-main rounded-circle d-flex justify-content-center align-items-center flex-shrink-0">
                    <img src="assets/images/notification/profile-2.png" alt="Image">
                  </span>
                  <div>
                    <h6 class="text-md fw-semibold mb-4">Robiul Hasan</h6>
                    <p class="mb-0 text-sm text-secondary-light text-w-200-px">Invite you to prototyping</p>
                  </div>
                </div>
                <span class="text-sm text-secondary-light flex-shrink-0">23 Mins ago</span>
              </a>

              <a href="javascript:void(0)"
                class="px-24 py-12 d-flex align-items-start gap-3 mb-2 justify-content-between">
                <div class="text-black hover-bg-transparent hover-text-primary d-flex align-items-center gap-3">
                  <span
                    class="w-44-px h-44-px bg-info-subtle text-info-main rounded-circle d-flex justify-content-center align-items-center flex-shrink-0">
                    DR
                  </span>
                  <div>
                    <h6 class="text-md fw-semibold mb-4">Darlene Robertson</h6>
                    <p class="mb-0 text-sm text-secondary-light text-w-200-px">Invite you to prototyping</p>
                  </div>
                </div>
                <span class="text-sm text-secondary-light flex-shrink-0">23 Mins ago</span>
              </a>
            </div>

            <div class="text-center py-12 px-16">
              <a href="javascript:void(0)" class="text-primary-600 fw-semibold text-md hover-underline">See All Notification</a>
            </div>

          </div>
        </div><!-- Notification dropdown end -->

      </div>
    </div>
  </div>
</div>

    <div class="dashboard-main-body">

        <div class="breadcrumb d-flex flex-wrap align-items-center justify-content-between gap-3 mb-24">
            <div class="">
                <h1 class="fw-semibold mb-4 h6 text-primary-light">Employee Details</h1>
                <div class="">
                    <a href="index.php" class="text-secondary-light hover-text-primary hover-underline">Dashboard </a>
                    <a href="employee-list.php" class="text-secondary-light hover-text-primary hover-underline"> /
                        HRM</a>
                    <span class="text-secondary-light">/ Employee Details</span>
                </div>
            </div>
            <button type="button"
                class="my-sidebar-btn btn btn-primary-600 d-flex align-items-center gap-6 bg-base text-primary-light bg-hover-primary-600">
                <span class="d-flex text-md">
                    <i class="ri-lock-2-line"></i>
                </span>
                Login Details
            </button>
        </div>

        <div class="mt-24">
            <div class="card h-100">
                <div class="card-body p-24">
                    <div class="d-flex gap-32 flex-md-row flex-column">
                        <div class="max-w-300-px w-100 text-center">
                            <figure class="mb-24 w-120-px h-120-px mx-auto rounded-circle overflow-hidden">
                                <img src="assets/images/thumbs/teacher-details-img.png" alt="employee Image"
                                    class="w-100 h-100 object-fit-cover">
                            </figure>
                            <h2 class="h6 text-primary-light mb-16 fw-semibold">Marvin McKinney</h2>
                            <p class="mb-0">ID: <span class="text-primary-600 fw-semibold"> AD1256589</span>
                            </p>
                            <p class="mb-0">Subject: <span class="text-primary-light fw-semibold">Mathematics</span>
                            </p>
                            <div class="mt-32 d-flex gap-16 w-100">
                                <button type="button"
                                    class="btn border fw-medium border-danger-600 bg-hover-danger-200 text-danger-600 text-md d-flex justify-content-center align-items-center gap-8 flex-grow-1 px-12 py-8 radius-8"
                                    data-bs-toggle="modal" data-bs-target="#exampleModalDelete">
                                    <span class="d-flex text-lg">
                                        <i class="ri-delete-bin-2-line"></i>
                                    </span>
                                    Suspend
                                </button>
                                <a href="edit-employee.php"
                                    class="btn btn-primary-600 border fw-medium border-primary-600 text-md d-flex justify-content-center align-items-center gap-8 flex-grow-1 px-12 py-8 radius-8">
                                    <span class="d-flex text-lg">
                                        <i class="ri-edit-line"></i>
                                    </span>
                                    Edit
                                </a>
                            </div>
                        </div>
                        <div class="">
                            <span class="h-100 w-1-px bg-neutral-200"></span>
                        </div>
                        <div class="flex-grow-1">
                            <div class="pb-16 border-bottom d-flex align-items-center justify-content-between gap-20">
                                <h3 class="h6 text-primary-light text-lg mb-0 fw-semibold">Personal Info</h3>
                                <span
                                    class="bg-success-100 text-success-600 px-16 py-4 radius-4 fw-medium text-sm">Active</span>
                            </div>
                            <div class="mt-16 d-flex flex-column gap-8">
                                <div class="d-flex gap-4">
                                    <span class="fw-semibold text-sm text-primary-light w-110-px">Class</span>
                                    <span class="fw-normal text-sm text-secondary-light">: Class 6 (2025-26)</span>
                                </div>
                                <div class="d-flex gap-4">
                                    <span class="fw-semibold text-sm text-primary-light w-110-px">Contract Type</span>
                                    <span class="fw-normal text-sm text-secondary-light">: Permanent</span>
                                </div>
                                <div class="d-flex gap-4">
                                    <span class="fw-semibold text-sm text-primary-light w-110-px">Shift</span>
                                    <span class="fw-normal text-sm text-secondary-light">: Morning</span>
                                </div>
                                <div class="d-flex gap-4">
                                    <span class="fw-semibold text-sm text-primary-light w-110-px">Work Location</span>
                                    <span class="fw-normal text-sm text-secondary-light">: 2nd Floor</span>
                                </div>
                                <div class="d-flex gap-4">
                                    <span class="fw-semibold text-sm text-primary-light w-110-px">Date Of Birth</span>
                                    <span class="fw-normal text-sm text-secondary-light">: 10 Nov 2006</span>
                                </div>
                                <div class="d-flex gap-4">
                                    <span class="fw-semibold text-sm text-primary-light w-110-px">Gender</span>
                                    <span class="fw-normal text-sm text-secondary-light">: Male</span>
                                </div>
                                <div class="d-flex gap-4">
                                    <span class="fw-semibold text-sm text-primary-light w-110-px">Join Date</span>
                                    <span class="fw-normal text-sm text-secondary-light">: 05 May 2012</span>
                                </div>
                                <div class="d-flex gap-4">
                                    <span class="fw-semibold text-sm text-primary-light w-110-px">Phone Number</span>
                                    <span class="fw-normal text-sm text-primary-600">: 789678456</span>
                                </div>
                                <div class="d-flex gap-4">
                                    <span class="fw-semibold text-sm text-primary-light w-110-px">Email</span>
                                    <span class="fw-normal text-sm text-primary-600">: set@example.com</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="my-16">
                <ul class="nav nav-pills bordered-tab mb-3" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button
                            class="nav-link d-flex align-items-center gap-8 text-secondary-light fw-medium text-sm text-hover-primary-600 text-capitalize bg-transparent px-20 py-12  active"
                            id="pills-employeeDetails-tab" data-bs-toggle="pill" data-bs-target="#pills-employeeDetails"
                            type="button" role="tab" aria-controls="pills-employeeDetails" aria-selected="true">
                            <span class="d-flex tab-icon line-height-1 text-md">
                                <i class="ri-group-line"></i>
                            </span>
                            employee Details
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button
                            class="nav-link d-flex align-items-center gap-8 text-secondary-light fw-medium text-sm text-hover-primary-600 text-capitalize bg-transparent px-20 py-12 "
                            id="pills-attendance-tab" data-bs-toggle="pill" data-bs-target="#pills-attendance"
                            type="button" role="tab" aria-controls="pills-attendance" aria-selected="false">
                            <span class="d-flex tab-icon line-height-1 text-md">
                                <i class="ri-calendar-check-line"></i>
                            </span>
                            Attendance
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button
                            class="nav-link d-flex align-items-center gap-8 text-secondary-light fw-medium text-sm text-hover-primary-600 text-capitalize bg-transparent px-20 py-12 "
                            id="pills-leave-tab" data-bs-toggle="pill" data-bs-target="#pills-leave" type="button"
                            role="tab" aria-controls="pills-leave" aria-selected="false">
                            <span class="d-flex tab-icon line-height-1 text-md">
                                <i class="ri-login-box-line"></i>
                            </span>
                            Leave
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button
                            class="nav-link d-flex align-items-center gap-8 text-secondary-light fw-medium text-sm text-hover-primary-600 text-capitalize bg-transparent px-20 py-12 "
                            id="pills-payroll-tab" data-bs-toggle="pill" data-bs-target="#pills-payroll" type="button"
                            role="tab" aria-controls="pills-payroll" aria-selected="false">
                            <span class="d-flex tab-icon line-height-1 text-md">
                                <i class="ri-money-dollar-box-line"></i>
                            </span>
                            Payroll 
                        </button>
                    </li>
                </ul>


                <div class="tab-content" id="pills-tabContent">

                    <!-- employee Details tab start -->
                    <div class="tab-pane fade show active" id="pills-employeeDetails" role="tabpanel"
                        aria-labelledby="pills-employeeDetails-tab" tabindex="0">
                        <div class="row gy-4">
                            <div class="col-md-12">
                                <div class="shadow-1 radius-12 bg-base h-100 overflow-hidden">
                                    <div
                                        class="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center justify-content-between">
                                        <h6 class="text-lg fw-semibold mb-0">Profile Detail</h6>
                                    </div>
                                    <div class="card-body p-0">
                                        <div class="p-20">
                                            <div class="row gy-4">
                                                <div class="col-md-3 col-sm-6">
                                                    <div class="">
                                                        <h6 class="text-md mb-2 fw-medium flex-grow-1">Date of Birth
                                                        </h6>
                                                        <span class="">10 Nov 1995</span>
                                                    </div>
                                                </div>
                                                <div class="col-md-3 col-sm-6">
                                                    <div class="">
                                                        <h6 class="text-md mb-2 fw-medium flex-grow-1">Martial Status
                                                        </h6>
                                                        <span class="">Married </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-3 col-sm-6">
                                                    <div class="">
                                                        <h6 class="text-md mb-2 fw-medium flex-grow-1">Qualification
                                                        </h6>
                                                        <span class="">MBA</span>
                                                    </div>
                                                </div>
                                                <div class="col-md-3 col-sm-6">
                                                    <div class="">
                                                        <h6 class="text-md mb-2 fw-medium flex-grow-1">Experience</h6>
                                                        <span class="">7 Years</span>
                                                    </div>
                                                </div>
                                                <div class="col-md-3 col-sm-6">
                                                    <div class="">
                                                        <h6 class="text-md mb-2 fw-medium flex-grow-1">Father Name </h6>
                                                        <span class="">Ralph Edwards</span>
                                                    </div>
                                                </div>
                                                <div class="col-md-3 col-sm-6">
                                                    <div class="">
                                                        <h6 class="text-md mb-2 fw-medium flex-grow-1">Mother Name</h6>
                                                        <span class="">Floyd Miles</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="shadow-1 radius-12 bg-base h-100 overflow-hidden">
                                    <div
                                        class="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center justify-content-between">
                                        <h6 class="text-lg fw-semibold mb-0">Previous School Details</h6>
                                    </div>
                                    <div class="card-body p-0">
                                        <div class="p-20">
                                            <div class="row gy-4">
                                                <div class="col-sm-12">
                                                    <div class="">
                                                        <h6 class="text-md mb-2 fw-medium flex-grow-1">Previous School
                                                            Name</h6>
                                                        <span class="">Stuyvesant High School</span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="">
                                                        <h6 class="text-md mb-2 fw-medium flex-grow-1">Current School
                                                            Name</h6>
                                                        <span class="">Bronx High School of Science</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="shadow-1 radius-12 bg-base h-100 overflow-hidden">
                                    <div
                                        class="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center justify-content-between">
                                        <h6 class="text-lg fw-semibold mb-0">Address</h6>
                                    </div>
                                    <div class="card-body p-0">
                                        <div class="p-20">
                                            <div class="row gy-4">
                                                <div class="col-sm-12">
                                                    <div class="">
                                                        <h6 class="text-md mb-2 fw-medium flex-grow-1">Current Address
                                                        </h6>
                                                        <span class="">8502 Preston Rd. Inglewood, Maine 98380</span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="">
                                                        <h6 class="text-md mb-2 fw-medium flex-grow-1">Permanent Address
                                                        </h6>
                                                        <span class="">2118 Thornridge Cir. Syracuse, Connecticut
                                                            35624</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="shadow-1 radius-12 bg-base h-100 overflow-hidden">
                                    <div
                                        class="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center justify-content-between">
                                        <h6 class="text-lg fw-semibold mb-0">Bank Details</h6>
                                    </div>
                                    <div class="card-body p-0">
                                        <div class="p-20">
                                            <div class="row gy-4">
                                                <div class="col-sm-4">
                                                    <div class="">
                                                        <h6 class="text-md mb-2 fw-medium flex-grow-1">Bank Name</h6>
                                                        <span class="">Bank of America</span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <div class="">
                                                        <h6 class="text-md mb-2 fw-medium flex-grow-1">Branch</h6>
                                                        <span class="">New York</span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <div class="">
                                                        <h6 class="text-md mb-2 fw-medium flex-grow-1">IFSC Code</h6>
                                                        <span class="">5283209832</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="shadow-1 radius-12 bg-base h-100 overflow-hidden">
                                    <div
                                        class="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center justify-content-between">
                                        <h6 class="text-lg fw-semibold mb-0">Medical Details</h6>
                                    </div>
                                    <div class="card-body p-0">
                                        <div class="p-20">
                                            <div class="row gy-4">
                                                <div class="col-sm-4">
                                                    <div class="">
                                                        <h6 class="text-md mb-2 fw-medium flex-grow-1">Blood Group</h6>
                                                        <span class="">O+</span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <div class="">
                                                        <h6 class="text-md mb-2 fw-medium flex-grow-1">Height</h6>
                                                        <span class="">5.2</span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <div class="">
                                                        <h6 class="text-md mb-2 fw-medium flex-grow-1">Weight</h6>
                                                        <span class="">60kg</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="shadow-1 radius-12 bg-base h-100 overflow-hidden">
                                    <div
                                        class="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center justify-content-between">
                                        <h6 class="text-lg fw-semibold mb-0">Documents</h6>
                                    </div>
                                    <div class="card-body p-20">
                                        <div class="p-10 border radius-8">
                                            <div class="d-flex align-items-center justify-content-between gap-20">
                                                <div class="d-flex align-items-center gap-12">
                                                    <span
                                                        class="w-36-px h-36-px radius-4 bg-neutral-50 d-flex justify-content-center align-items-center text-xl">
                                                        <i class="ri-file-text-line"></i>
                                                    </span>
                                                    <span
                                                        class="text-md text-secondary-light">BirthCertificate.pdf</span>
                                                </div>
                                                <button type="button"
                                                    class="w-36-px h-36-px radius-4 bg-primary-50 bg-hover-primary-100 text-primary-600 d-flex justify-content-center align-items-center text-xl">
                                                    <i class="ri-download-2-line"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="shadow-1 radius-12 bg-base h-100 overflow-hidden">
                                    <div
                                        class="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center justify-content-between">
                                        <h6 class="text-lg fw-semibold mb-0">Social Media</h6>
                                    </div>
                                    <div class="card-body p-0">
                                        <div class="p-20">
                                            <div class="row gy-4">
                                                <div class="col-sm-4">
                                                    <div class="">
                                                        <h6 class="text-md mb-2 fw-medium flex-grow-1">Facebook</h6>
                                                        <span class="">www.facebook.com</span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <div class="">
                                                        <h6 class="text-md mb-2 fw-medium flex-grow-1">LinkedIn</h6>
                                                        <span class="">www.linkedin.com</span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <div class="">
                                                        <h6 class="text-md mb-2 fw-medium flex-grow-1">Instagram</h6>
                                                        <span class="">www.instagram.com</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- employee Details tab end -->

                    <!-- Attendance tab start -->
                    <div class="tab-pane fade" id="pills-attendance" role="tabpanel"
                        aria-labelledby="pills-attendance-tab" tabindex="0">
                        <div class="shadow-1 radius-12 bg-base h-100 overflow-hidden">
                            <div
                                class="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center justify-content-between">
                                <h6 class="text-lg fw-semibold mb-0">Attendance</h6>
                            </div>
                            <div class="card-body p-0">
                                <div class="px-20 pt-20">
                                    <div class="row row-cols-xxl-5 row-cols-lg-3 row-cols-sm-2 row-cols-1 g-3">
                                        <div class="col">
                                            <div
                                                class="card px-20 py-28 shadow-2 radius-8 h-100 border border-neutral-200 shadow-none gradient-bg-end-7">
                                                <div class="card-body p-0">
                                                    <div
                                                        class="d-flex flex-wrap align-items-center justify-content-between gap-1">
                                                        <div>
                                                            <h6 class="fw-semibold mb-2">227</h6>
                                                            <span class="fw-medium text-secondary-light text-sm">Total
                                                                Present</span>
                                                        </div>
                                                        <span
                                                            class="mb-0 w-48-px h-48-px bg-success-600 text-white flex-shrink-0 text-white d-flex justify-content-center align-items-center rounded-circle h6 mb-0">
                                                            <img src="assets/images/icons/attendence-icon1.png"
                                                                alt="Present Icon">
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div
                                                class="card px-20 py-28 shadow-2 radius-8 h-100 border border-neutral-200 shadow-none gradient-bg-end-8">
                                                <div class="card-body p-0">
                                                    <div
                                                        class="d-flex flex-wrap align-items-center justify-content-between gap-1">
                                                        <div>
                                                            <h6 class="fw-semibold mb-2">70</h6>
                                                            <span class="fw-medium text-secondary-light text-sm">Total
                                                                Absent</span>
                                                        </div>
                                                        <span
                                                            class="mb-0 w-48-px h-48-px bg-danger-600 text-white flex-shrink-0 text-white d-flex justify-content-center align-items-center rounded-circle h6 mb-0">
                                                            <img src="assets/images/icons/attendence-icon2.png"
                                                                alt="Absent Icon">
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div
                                                class="card px-20 py-28 shadow-2 radius-8 h-100 border border-neutral-200 shadow-none gradient-bg-end-9">
                                                <div class="card-body p-0">
                                                    <div
                                                        class="d-flex flex-wrap align-items-center justify-content-between gap-1">
                                                        <div>
                                                            <h6 class="fw-semibold mb-2">27</h6>
                                                            <span class="fw-medium text-secondary-light text-sm">Half
                                                                Day</span>
                                                        </div>
                                                        <span
                                                            class="mb-0 w-48-px h-48-px bg-purple-600 text-white flex-shrink-0 text-white d-flex justify-content-center align-items-center rounded-circle h6 mb-0">
                                                            <img src="assets/images/icons/attendence-icon3.png"
                                                                alt="Calendar Icon">
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div
                                                class="card px-20 py-28 shadow-2 radius-8 h-100 border border-neutral-200 shadow-none gradient-bg-end-10">
                                                <div class="card-body p-0">
                                                    <div
                                                        class="d-flex flex-wrap align-items-center justify-content-between gap-1">
                                                        <div>
                                                            <h6 class="fw-semibold mb-2">28</h6>
                                                            <span class="fw-medium text-secondary-light text-sm">Total
                                                                Late</span>
                                                        </div>
                                                        <span
                                                            class="mb-0 w-48-px h-48-px bg-info-600 text-white flex-shrink-0 text-white d-flex justify-content-center align-items-center rounded-circle h6 mb-0">
                                                            <img src="assets/images/icons/attendence-icon4.png"
                                                                alt="Clock Icon">
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div
                                                class="card px-20 py-28 shadow-2 radius-8 h-100 border border-neutral-200 shadow-none gradient-bg-end-11">
                                                <div class="card-body p-0">
                                                    <div
                                                        class="d-flex flex-wrap align-items-center justify-content-between gap-1">
                                                        <div>
                                                            <h6 class="fw-semibold mb-2">12</h6>
                                                            <span class="fw-medium text-secondary-light text-sm">Total
                                                                Holiday</span>
                                                        </div>
                                                        <span
                                                            class="mb-0 w-48-px h-48-px bg-orange text-white flex-shrink-0 text-white d-flex justify-content-center align-items-center rounded-circle h6 mb-0">
                                                            <img src="assets/images/icons/attendence-icon5.png"
                                                                alt="Holiday Icon">
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mt-24 mb-16 mx-20">
                                    <div
                                        class="d-flex flex-wrap align-items-center gap-24 justify-content-between flex-wrap">
                                        <div class="d-flex flex-wrap align-items-center gap-16 ">
                                            <div class="">
                                                <select class="form-control form-select">
                                                    <option value="Jun 2025/2026">Jun 2025/2026</option>
                                                    <option value="Jun 2026/2027">Jun 2026/2027</option>
                                                    <option value="Jun 2027/2028">Jun 2027/2028</option>
                                                    <option value="Jun 2028/2029">Jun 2028/2029</option>
                                                </select>
                                            </div>
                                            <div class="dropdown">
                                                <button type="button"
                                                    class="px-12 py-8 border border-neutral-300 radius-8 d-flex align-items-center gap-20"
                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                    <span
                                                        class="d-flex align-items-center gap-1 text-secondary-light text-sm">
                                                        <i class="ri-file-upload-line text-md line-height-1"></i>
                                                        Export
                                                    </span>
                                                    <span class="">
                                                        <i class="ri-arrow-down-s-line"></i>
                                                    </span>
                                                </button>
                                                <ul class="dropdown-menu p-12 border bg-base shadow">
                                                    <li>
                                                        <button type="button"
                                                            class="dropdown-item px-16 py-8 rounded text-secondary-light bg-hover-neutral-200 text-hover-neutral-900 d-flex align-items-center gap-10"
                                                            data-bs-toggle="modal" data-bs-target="#exampleModalView">
                                                            <i class="ri-file-3-line"></i>
                                                            PDF
                                                        </button>
                                                    </li>
                                                    <li>
                                                        <button type="button"
                                                            class="dropdown-item px-16 py-8 rounded text-secondary-light bg-hover-neutral-200 text-hover-neutral-900 d-flex align-items-center gap-10"
                                                            data-bs-toggle="modal" data-bs-target="#exampleModalEdit">
                                                            <i class="ri-file-excel-line"></i>
                                                            Excel
                                                        </button>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center flex-wrap gap-8">
                                            <p class="text-primary-light text-sm fw-medium mb-0">
                                                Present:
                                                <span class="fw-semibold text-success-600">P </span>
                                            </p>
                                            <p class="text-primary-light text-sm fw-medium mb-0">
                                                Absent:
                                                <span class="fw-semibold text-danger-600">A </span>
                                            </p>
                                            <p class="text-primary-light text-sm fw-medium mb-0">
                                                Holiday:
                                                <span class="fw-semibold text-warning-600">H </span>
                                            </p>
                                            <p class="text-primary-light text-sm fw-medium mb-0">
                                                Late:
                                                <span class="fw-semibold text-info-600">L </span>
                                            </p>
                                            <p class="text-primary-light text-sm fw-medium mb-0">
                                                Half Day:
                                                <span class="fw-semibold text-purple-600">F </span>
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <div class="table-responsive overflow-x-auto">
                                    <table class="table mb-0 table-heading-dark-mode">
                                        <thead>
                                            <tr>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">Month
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">1</th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">2</th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">3</th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">4</th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">5</th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">6</th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">7</th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">8</th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">9</th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">10
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">11
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">12
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">13
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">14
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">15
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">15
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">16
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">17
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">18
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">19
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">20
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">21
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">22
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">23
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">24
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">25
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">26
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">27
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">28
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">29
                                                </th>
                                                <th class="bg-neutral-100 text-sm text-primary-light px-10 py-16">30
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="px-10 py-16 text-sm">Jan</td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">P</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">H</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">A</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">P</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">P</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">P</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">F</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">L</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">H</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">P</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">A</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">P</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">P</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">L</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">h</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">P</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">P</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">P</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">P</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">P</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">F</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">H</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">P</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">P</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">P</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">P</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">P</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">A</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">H</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">p</span>
                                                </td>
                                                <td class="px-10 py-14 text-sm text-uppercase">
                                                    <span class="attendance">p</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="px-10 py-16 text-sm">Feb</td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">F</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">L</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">F</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">L</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">F</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">L</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">F</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">L</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                            </tr>
                                            <tr>
                                                <td class="px-10 py-16 text-sm">Mar</td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">F</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">L</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">L</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">F</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">L</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">F</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                            </tr>
                                            <tr>
                                                <td class="px-10 py-16 text-sm">Apr</td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">F</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">L</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">L</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">F</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">F</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">L</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                            </tr>
                                            <tr>
                                                <td class="px-10 py-16 text-sm">May</td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">F</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">L</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">L</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">F</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">F</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">L</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                            </tr>
                                            <tr>
                                                <td class="px-10 py-16 text-sm">May</td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">F</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">L</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">L</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">F</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">F</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">L</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">H</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">P</span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance">A</span></td>
                                            </tr>
                                            <tr>
                                                <td class="px-10 py-16 text-sm">Jun</td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                            </tr>
                                            <tr>
                                                <td class="px-10 py-16 text-sm">Ju</td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                            </tr>
                                            <tr>
                                                <td class="px-10 py-16 text-sm">Aug</td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                            </tr>
                                            <tr>
                                                <td class="px-10 py-16 text-sm">Sep</td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                            </tr>
                                            <tr>
                                                <td class="px-10 py-16 text-sm">Oct</td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                            </tr>
                                            <tr>
                                                <td class="px-10 py-16 text-sm">Nov</td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                            </tr>
                                            <tr>
                                                <td class="px-10 py-16 text-sm">Dec</td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                                <td class="px-10 py-16 text-sm"><span class="attendance"></span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Attendance tab end -->

                    <!-- leaves tab start -->
                    <div class="tab-pane fade" id="pills-leave" role="tabpanel" aria-labelledby="pills-leave-tab"
                        tabindex="0">
                        <div class="shadow-1 radius-12 bg-base h-100 overflow-hidden">
                            <div
                                class="card-header border-bottom bg-base py-10 px-20 d-flex align-items-center justify-content-between">
                                <h6 class="text-lg fw-semibold mb-0">Leave </h6>
                                <button type="button"
                                    class="apply-leave-btn btn btn-primary-600 d-flex align-items-center gap-6 py-8 text-sm">
                                    <span class="d-flex text-sm">
                                        <i class="ri-calendar-close-line"></i>
                                    </span>
                                    Apply Leave
                                </button>
                            </div>
                            <div class="card-body p-0 dataTable-wrapper">
                                <div
                                    class="d-flex flex-wrap align-items-center gap-24 justify-content-between px-20 py-12">
                                    <div class="d-flex flex-wrap align-items-center gap-16">
                                        <form class="navbar-search dt-search m-0">
                                            <input type="text" class="dt-input bg-transparent radius-4"
                                                aria-controls="dataTable" name="search" placeholder="Search...">
                                            <iconify-icon icon="ion:search-outline" class="icon"></iconify-icon>
                                        </form>
                                        <div class="">
                                            <select class="form-control form-select">
                                                <option value="Year 2025/2026">Year 2025/2026</option>
                                                <option value="Year 2026/2027">Year 2026/2027</option>
                                                <option value="Year 2027/2028">Year 2027/2028</option>
                                                <option value="Year 2028/2029">Year 2028/2029</option>
                                            </select>
                                        </div>
                                        <div class="dropdown">
                                            <button type="button"
                                                class="px-12 py-5-px border border-neutral-300 radius-8 d-flex align-items-center gap-20 "
                                                data-bs-toggle="dropdown" aria-expanded="false">
                                                <span
                                                    class="d-flex align-items-center gap-1 text-secondary-light text-sm">
                                                    <i class="ri-file-upload-line text-md line-height-1"></i>
                                                    Export
                                                </span>
                                                <span class="">
                                                    <i class="ri-arrow-down-s-line"></i>
                                                </span>
                                            </button>
                                            <ul class="dropdown-menu p-12 border bg-base shadow">
                                                <li>
                                                    <button type="button"
                                                        class="dropdown-item px-16 py-8 rounded text-secondary-light bg-hover-neutral-200 text-hover-neutral-900 d-flex align-items-center gap-10"
                                                        data-bs-toggle="modal" data-bs-target="#exampleModalView">
                                                        <i class="ri-file-3-line"></i>
                                                        PDF
                                                    </button>
                                                </li>
                                                <li>
                                                    <button type="button"
                                                        class="dropdown-item px-16 py-8 rounded text-secondary-light bg-hover-neutral-200 text-hover-neutral-900 d-flex align-items-center gap-10"
                                                        data-bs-toggle="modal" data-bs-target="#exampleModalEdit">
                                                        <i class="ri-file-excel-line"></i>
                                                        Excel
                                                    </button>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center gap-8 text-secondary-light">
                                        <span class="">
                                            Rows per page:
                                        </span>
                                        <div class="dt-length">
                                            <select name="dataTable_length" aria-controls="dataTable"
                                                class="dt-input form-control form-select">
                                                <option value="5">5</option>
                                                <option value="10" selected>10</option>
                                                <option value="25">25</option>
                                                <option value="50">50</option>
                                                <option value="100">100</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <table class="table bordered-table mb-0 table-heading-dark-mode w-100 data-table"
                                    id="dataTable" data-page-length='10'>
                                    <thead>
                                        <tr>
                                            <th scope="col">
                                                <div class="form-check style-check d-flex align-items-center">
                                                    <input class="form-check-input" type="checkbox">
                                                    <label class="form-check-label">
                                                        S.L
                                                    </label>
                                                </div>
                                            </th>
                                            <th scope="col">Leave Type</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">Duration</th>
                                            <th scope="col">Apply Date</th>
                                            <th scope="col">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <div class="form-check style-check d-flex align-items-center">
                                                    <input class="form-check-input" type="checkbox">
                                                    <label class="form-check-label">
                                                        01
                                                    </label>
                                                </div>
                                            </td>
                                            <td>Medical Leave</td>
                                            <td>07 May 2025 - 08 may 2025</td>
                                            <td>1</td>
                                            <td>07 May 2025 </td>
                                            <td>
                                                <span
                                                    class="bg-success-100 text-success-600 px-20 py-4 radius-4 fw-medium text-sm">Approved</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check style-check d-flex align-items-center">
                                                    <input class="form-check-input" type="checkbox">
                                                    <label class="form-check-label">
                                                        02
                                                    </label>
                                                </div>
                                            </td>
                                            <td>Special Leave</td>
                                            <td>07 May 2025 - 08 may 2025</td>
                                            <td>3</td>
                                            <td>07 May 2025 </td>
                                            <td>
                                                <span
                                                    class="bg-warning-100 text-warning-600 px-20 py-4 radius-4 fw-medium text-sm">Pending</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check style-check d-flex align-items-center">
                                                    <input class="form-check-input" type="checkbox">
                                                    <label class="form-check-label">
                                                        03
                                                    </label>
                                                </div>
                                            </td>
                                            <td>Medical Leave</td>
                                            <td>07 May 2025 - 08 may 2025</td>
                                            <td>5</td>
                                            <td>07 May 2025 </td>
                                            <td>
                                                <span
                                                    class="bg-success-100 text-success-600 px-20 py-4 radius-4 fw-medium text-sm">Approved</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check style-check d-flex align-items-center">
                                                    <input class="form-check-input" type="checkbox">
                                                    <label class="form-check-label">
                                                        04
                                                    </label>
                                                </div>
                                            </td>
                                            <td>Casual Leave</td>
                                            <td>07 May 2025 - 08 may 2025</td>
                                            <td>6</td>
                                            <td>07 May 2025 </td>
                                            <td>
                                                <span
                                                    class="bg-warning-100 text-warning-600 px-20 py-4 radius-4 fw-medium text-sm">Pending</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check style-check d-flex align-items-center">
                                                    <input class="form-check-input" type="checkbox">
                                                    <label class="form-check-label">
                                                        05
                                                    </label>
                                                </div>
                                            </td>
                                            <td>Medical Leave</td>
                                            <td>07 May 2025 - 08 may 2025</td>
                                            <td>1</td>
                                            <td>07 May 2025 </td>
                                            <td>
                                                <span
                                                    class="bg-success-100 text-success-600 px-20 py-4 radius-4 fw-medium text-sm">Approved</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check style-check d-flex align-items-center">
                                                    <input class="form-check-input" type="checkbox">
                                                    <label class="form-check-label">
                                                        06
                                                    </label>
                                                </div>
                                            </td>
                                            <td>Special Leave</td>
                                            <td>07 May 2025 - 08 may 2025</td>
                                            <td>2</td>
                                            <td>07 May 2025 </td>
                                            <td>
                                                <span
                                                    class="bg-danger-100 text-danger-600 px-20 py-4 radius-4 fw-medium text-sm">Rejected</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check style-check d-flex align-items-center">
                                                    <input class="form-check-input" type="checkbox">
                                                    <label class="form-check-label">
                                                        07
                                                    </label>
                                                </div>
                                            </td>
                                            <td>Medical Leave</td>
                                            <td>07 May 2025 - 08 may 2025</td>
                                            <td>5</td>
                                            <td>07 May 2025 </td>
                                            <td>
                                                <span
                                                    class="bg-success-100 text-success-600 px-20 py-4 radius-4 fw-medium text-sm">Approved</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check style-check d-flex align-items-center">
                                                    <input class="form-check-input" type="checkbox">
                                                    <label class="form-check-label">
                                                        08
                                                    </label>
                                                </div>
                                            </td>
                                            <td>Casual Leave</td>
                                            <td>07 May 2025 - 08 may 2025</td>
                                            <td>6</td>
                                            <td>07 May 2025 </td>
                                            <td>
                                                <span
                                                    class="bg-danger-100 text-danger-600 px-20 py-4 radius-4 fw-medium text-sm">Rejected</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check style-check d-flex align-items-center">
                                                    <input class="form-check-input" type="checkbox">
                                                    <label class="form-check-label">
                                                        09
                                                    </label>
                                                </div>
                                            </td>
                                            <td>Medical Leave</td>
                                            <td>07 May 2025 - 08 may 2025</td>
                                            <td>1</td>
                                            <td>07 May 2025 </td>
                                            <td>
                                                <span
                                                    class="bg-success-100 text-success-600 px-20 py-4 radius-4 fw-medium text-sm">Approved</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="form-check style-check d-flex align-items-center">
                                                    <input class="form-check-input" type="checkbox">
                                                    <label class="form-check-label">
                                                        10
                                                    </label>
                                                </div>
                                            </td>
                                            <td>Special Leave</td>
                                            <td>07 May 2025 - 08 may 2025</td>
                                            <td>2</td>
                                            <td>07 May 2025 </td>
                                            <td>
                                                <span
                                                    class="bg-danger-100 text-danger-600 px-20 py-4 radius-4 fw-medium text-sm">Rejected</span>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!-- leaves tab start -->

                    <!-- Payroll tab start -->
                    <div class="tab-pane fade" id="pills-payroll" role="tabpanel" aria-labelledby="pills-payroll-tab"
                        tabindex="0">
                        <div class="shadow-1 radius-12 bg-base h-100 overflow-hidden">
                            <div
                                class="card-header border-bottom bg-base py-10 px-20 d-flex align-items-center justify-content-between">
                                <h6 class="text-lg fw-semibold mb-0">Payroll </h6>
                            </div>
                            <div class="card-body p-0 dataTable-wrapper">
                                <div
                                    class="d-flex flex-wrap align-items-center gap-24 justify-content-between px-20 py-16">
                                    <div class="d-flex flex-wrap align-items-center gap-16">
                                        <form class="navbar-search dt-search m-0">
                                            <input type="text" class="dt-input bg-transparent radius-4"
                                                aria-controls="dataTable" name="search" placeholder="Search...">
                                            <iconify-icon icon="ion:search-outline" class="icon"></iconify-icon>
                                        </form>
                                        <div class="">
                                            <select class="form-control form-select">
                                                <option value="Year 2025/2026">Year 2025/2026</option>
                                                <option value="Year 2026/2027">Year 2026/2027</option>
                                                <option value="Year 2027/2028">Year 2027/2028</option>
                                                <option value="Year 2028/2029">Year 2028/2029</option>
                                            </select>
                                        </div>
                                        <div class="dropdown">
                                            <button type="button"
                                                class="px-12 py-5-px border border-neutral-300 radius-8 d-flex align-items-center gap-20 "
                                                data-bs-toggle="dropdown" aria-expanded="false">
                                                <span
                                                    class="d-flex align-items-center gap-1 text-secondary-light text-sm">
                                                    <i class="ri-file-upload-line text-md line-height-1"></i>
                                                    Export
                                                </span>
                                                <span class="">
                                                    <i class="ri-arrow-down-s-line"></i>
                                                </span>
                                            </button>
                                            <ul class="dropdown-menu p-12 border bg-base shadow">
                                                <li>
                                                    <button type="button"
                                                        class="dropdown-item px-16 py-8 rounded text-secondary-light bg-hover-neutral-200 text-hover-neutral-900 d-flex align-items-center gap-10"
                                                        data-bs-toggle="modal" data-bs-target="#exampleModalView">
                                                        <i class="ri-file-3-line"></i>
                                                        PDF
                                                    </button>
                                                </li>
                                                <li>
                                                    <button type="button"
                                                        class="dropdown-item px-16 py-8 rounded text-secondary-light bg-hover-neutral-200 text-hover-neutral-900 d-flex align-items-center gap-10"
                                                        data-bs-toggle="modal" data-bs-target="#exampleModalEdit">
                                                        <i class="ri-file-excel-line"></i>
                                                        Excel
                                                    </button>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center gap-8 text-secondary-light">
                                        <span class="">
                                            Rows per page:
                                        </span>
                                        <div class="dt-length">
                                            <select name="dataTable_length" aria-controls="dataTable"
                                                class="dt-input form-control form-select">
                                                <option value="5">5</option>
                                                <option value="10" selected>10</option>
                                                <option value="25">25</option>
                                                <option value="50">50</option>
                                                <option value="100">100</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <table class="table bordered-table mb-0 table-heading-dark-mode w-100 data-table"
                                    id="dataTableTwo" data-page-length='10'>
                                    <thead>
                                        <tr>
                                            <th scope="col">
                                                <div class="form-check style-check d-flex align-items-center">
                                                    <input class="form-check-input" type="checkbox">
                                                    <label class="form-check-label">
                                                        S.L
                                                    </label>
                                                </div>
                                            </th>
                                            <th scope="col">Invoice ID</th>
                                            <th scope="col">Salary For</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">Net Salary</th>
                                            <th scope="col">Payment Method</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                              <tbody>
                                    <tr>
                                        <td>
                                        <div class="form-check style-check d-flex align-items-center">
                                            <input class="form-check-input" type="checkbox">
                                            <label class="form-check-label">01</label>
                                        </div>
                                        </td>
                                        <td><span class="text-primary-600">AD52365</span></td>
                                        <td>Jan 2025</td>
                                        <td>07 Jan 2025</td>
                                        <td>$5,000</td>
                                        <td>Bank</td>
                                        <td>
                                        <span class="bg-success-100 text-success-600 px-20 py-4 radius-4 fw-medium text-sm">
                                            Paid
                                        </span>
                                        </td>
                                        <td>
                                        <button type="button"
                                            class="bg-neutral-200 bg-hover-neutral-300 text-neutral-600 px-20 py-4 radius-4 fw-medium text-sm"
                                            data-bs-toggle="modal" data-bs-target="#payslipModal">
                                            View Payslip
                                        </button>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                        <div class="form-check style-check d-flex align-items-center">
                                            <input class="form-check-input" type="checkbox">
                                            <label class="form-check-label">02</label>
                                        </div>
                                        </td>
                                        <td><span class="text-primary-600">AD52366</span></td>
                                        <td>Feb 2025</td>
                                        <td>08 Feb 2025</td>
                                        <td>$4,800</td>
                                        <td>Cash</td>
                                        <td>
                                        <span class="bg-warning-100 text-warning-600 px-20 py-4 radius-4 fw-medium text-sm">
                                            Pending
                                        </span>
                                        </td>
                                        <td>
                                        <button type="button"
                                            class="bg-neutral-200 bg-hover-neutral-300 text-neutral-600 px-20 py-4 radius-4 fw-medium text-sm"
                                            data-bs-toggle="modal" data-bs-target="#payslipModal">
                                            View Payslip
                                        </button>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                        <div class="form-check style-check d-flex align-items-center">
                                            <input class="form-check-input" type="checkbox">
                                            <label class="form-check-label">03</label>
                                        </div>
                                        </td>
                                        <td><span class="text-primary-600">AD52367</span></td>
                                        <td>Mar 2025</td>
                                        <td>09 Mar 2025</td>
                                        <td>$5,100</td>
                                        <td>Bank</td>
                                        <td>
                                        <span class="bg-success-100 text-success-600 px-20 py-4 radius-4 fw-medium text-sm">
                                            Paid
                                        </span>
                                        </td>
                                        <td>
                                        <button type="button"
                                            class="bg-neutral-200 bg-hover-neutral-300 text-neutral-600 px-20 py-4 radius-4 fw-medium text-sm"
                                            data-bs-toggle="modal" data-bs-target="#payslipModal">
                                            View Payslip
                                        </button>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                        <div class="form-check style-check d-flex align-items-center">
                                            <input class="form-check-input" type="checkbox">
                                            <label class="form-check-label">04</label>
                                        </div>
                                        </td>
                                        <td><span class="text-primary-600">AD52368</span></td>
                                        <td>Apr 2025</td>
                                        <td>06 Apr 2025</td>
                                        <td>$4,950</td>
                                        <td>Online</td>
                                        <td>
                                        <span class="bg-danger-100 text-danger-600 px-20 py-4 radius-4 fw-medium text-sm">
                                            Failed
                                        </span>
                                        </td>
                                        <td>
                                        <button type="button"
                                            class="bg-neutral-200 bg-hover-neutral-300 text-neutral-600 px-20 py-4 radius-4 fw-medium text-sm"
                                            data-bs-toggle="modal" data-bs-target="#payslipModal">
                                            View Payslip
                                        </button>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                        <div class="form-check style-check d-flex align-items-center">
                                            <input class="form-check-input" type="checkbox">
                                            <label class="form-check-label">05</label>
                                        </div>
                                        </td>
                                        <td><span class="text-primary-600">AD52369</span></td>
                                        <td>May 2025</td>
                                        <td>05 May 2025</td>
                                        <td>$5,200</td>
                                        <td>Bank</td>
                                        <td>
                                        <span class="bg-success-100 text-success-600 px-20 py-4 radius-4 fw-medium text-sm">
                                            Paid
                                        </span>
                                        </td>
                                        <td>
                                        <button type="button"
                                            class="bg-neutral-200 bg-hover-neutral-300 text-neutral-600 px-20 py-4 radius-4 fw-medium text-sm"
                                            data-bs-toggle="modal" data-bs-target="#payslipModal">
                                            View Payslip
                                        </button>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                        <div class="form-check style-check d-flex align-items-center">
                                            <input class="form-check-input" type="checkbox">
                                            <label class="form-check-label">06</label>
                                        </div>
                                        </td>
                                        <td><span class="text-primary-600">AD52370</span></td>
                                        <td>Jun 2025</td>
                                        <td>06 Jun 2025</td>
                                        <td>$4,600</td>
                                        <td>Cash</td>
                                        <td>
                                        <span class="bg-warning-100 text-warning-600 px-20 py-4 radius-4 fw-medium text-sm">
                                            Pending
                                        </span>
                                        </td>
                                        <td>
                                        <button type="button"
                                            class="bg-neutral-200 bg-hover-neutral-300 text-neutral-600 px-20 py-4 radius-4 fw-medium text-sm"
                                            data-bs-toggle="modal" data-bs-target="#payslipModal">
                                            View Payslip
                                        </button>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                        <div class="form-check style-check d-flex align-items-center">
                                            <input class="form-check-input" type="checkbox">
                                            <label class="form-check-label">07</label>
                                        </div>
                                        </td>
                                        <td><span class="text-primary-600">AD52371</span></td>
                                        <td>Jul 2025</td>
                                        <td>08 Jul 2025</td>
                                        <td>$5,300</td>
                                        <td>Bank</td>
                                        <td>
                                        <span class="bg-success-100 text-success-600 px-20 py-4 radius-4 fw-medium text-sm">
                                            Paid
                                        </span>
                                        </td>
                                        <td>
                                        <button type="button"
                                            class="bg-neutral-200 bg-hover-neutral-300 text-neutral-600 px-20 py-4 radius-4 fw-medium text-sm"
                                            data-bs-toggle="modal" data-bs-target="#payslipModal">
                                            View Payslip
                                        </button>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                        <div class="form-check style-check d-flex align-items-center">
                                            <input class="form-check-input" type="checkbox">
                                            <label class="form-check-label">08</label>
                                        </div>
                                        </td>
                                        <td><span class="text-primary-600">AD52372</span></td>
                                        <td>Aug 2025</td>
                                        <td>05 Aug 2025</td>
                                        <td>$4,750</td>
                                        <td>Online</td>
                                        <td>
                                        <span class="bg-warning-100 text-warning-600 px-20 py-4 radius-4 fw-medium text-sm">
                                            Pending
                                        </span>
                                        </td>
                                        <td>
                                        <button type="button"
                                            class="bg-neutral-200 bg-hover-neutral-300 text-neutral-600 px-20 py-4 radius-4 fw-medium text-sm"
                                            data-bs-toggle="modal" data-bs-target="#payslipModal">
                                            View Payslip
                                        </button>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                        <div class="form-check style-check d-flex align-items-center">
                                            <input class="form-check-input" type="checkbox">
                                            <label class="form-check-label">09</label>
                                        </div>
                                        </td>
                                        <td><span class="text-primary-600">AD52373</span></td>
                                        <td>Sep 2025</td>
                                        <td>06 Sep 2025</td>
                                        <td>$5,400</td>
                                        <td>Bank</td>
                                        <td>
                                        <span class="bg-success-100 text-success-600 px-20 py-4 radius-4 fw-medium text-sm">
                                            Paid
                                        </span>
                                        </td>
                                        <td>
                                        <button type="button"
                                            class="bg-neutral-200 bg-hover-neutral-300 text-neutral-600 px-20 py-4 radius-4 fw-medium text-sm"
                                            data-bs-toggle="modal" data-bs-target="#payslipModal">
                                            View Payslip
                                        </button>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                        <div class="form-check style-check d-flex align-items-center">
                                            <input class="form-check-input" type="checkbox">
                                            <label class="form-check-label">10</label>
                                        </div>
                                        </td>
                                        <td><span class="text-primary-600">AD52374</span></td>
                                        <td>Oct 2025</td>
                                        <td>07 Oct 2025</td>
                                        <td>$4,850</td>
                                        <td>Cash</td>
                                        <td>
                                        <span class="bg-danger-100 text-danger-600 px-20 py-4 radius-4 fw-medium text-sm">
                                            Failed
                                        </span>
                                        </td>
                                        <td>
                                        <button type="button"
                                            class="bg-neutral-200 bg-hover-neutral-300 text-neutral-600 px-20 py-4 radius-4 fw-medium text-sm"
                                            data-bs-toggle="modal" data-bs-target="#payslipModal">
                                            View Payslip
                                        </button>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                        <div class="form-check style-check d-flex align-items-center">
                                            <input class="form-check-input" type="checkbox">
                                            <label class="form-check-label">11</label>
                                        </div>
                                        </td>
                                        <td><span class="text-primary-600">AD52375</span></td>
                                        <td>Nov 2025</td>
                                        <td>06 Nov 2025</td>
                                        <td>$5,150</td>
                                        <td>Bank</td>
                                        <td>
                                        <span class="bg-success-100 text-success-600 px-20 py-4 radius-4 fw-medium text-sm">
                                            Paid
                                        </span>
                                        </td>
                                        <td>
                                        <button type="button"
                                            class="bg-neutral-200 bg-hover-neutral-300 text-neutral-600 px-20 py-4 radius-4 fw-medium text-sm"
                                            data-bs-toggle="modal" data-bs-target="#payslipModal">
                                            View Payslip
                                        </button>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                        <div class="form-check style-check d-flex align-items-center">
                                            <input class="form-check-input" type="checkbox">
                                            <label class="form-check-label">12</label>
                                        </div>
                                        </td>
                                        <td><span class="text-primary-600">AD52376</span></td>
                                        <td>Dec 2025</td>
                                        <td>08 Dec 2025</td>
                                        <td>$5,000</td>
                                        <td>Online</td>
                                        <td>
                                        <span class="bg-success-100 text-success-600 px-20 py-4 radius-4 fw-medium text-sm">
                                            Paid
                                        </span>
                                        </td>
                                        <td>
                                        <button type="button"
                                            class="bg-neutral-200 bg-hover-neutral-300 text-neutral-600 px-20 py-4 radius-4 fw-medium text-sm"
                                            data-bs-toggle="modal" data-bs-target="#payslipModal">
                                            View Payslip
                                        </button>
                                        </td>
                                    </tr>
                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                    <!-- Payroll tab end -->

                </div>
            </div>
        </div>
    </div>

    <footer class="d-footer">
  <div class="">
    <p class="mb-0 text-center"> &copy; <span class="current-year"></span> Made With ❤️ by Wowtheme7.</p>
  </div>
</footer>
</main>

<!-- Login Details sidebar start -->
<div
    class="my-sidebar bg-white position-fixed end-0 top-0 h-100vh overflow-y-auto z-99 max-w-700-px w-100 translate-x-full duration-300 active-translate-0">
    <div class="px-20 py-12 border-bottom d-flex align-items-center justify-content-between gap-20">
        <h5 class="text-lg mb-0">Login Details</h5>
        <button type="button" class="close-my-sidebar text-danger-600 text-lg d-flex">
            <i class="ri-close-large-line"></i>
        </button>
    </div>
    <form action="#" class="d-flex flex-column">
        <div class="p-20">
            <div class="d-flex align-items-center gap-20">
                <figure class="w-72-px h-72-px rounded-circle overflow-hidden mb-0">
                    <img src="assets/images/thumbs/teacher-details-img.png" alt="employee Image"
                        class="w-100 h-100 object-fit-cover">
                </figure>
                <div class="flex-grow-1">
                    <h2 class="text-xl text-primary-light mb-4">Marvin McKinney</h2>
                    <p class="mb-0">Roll No: <span class="text-primary-light fw-semibold">10</span> </p>
                </div>
            </div>
        </div>
        <div class="table-bottom-info-none">
            <table class="table bordered-table mb-0 table-heading-dark-mode w-100 data-table" id="loginDetailsTable"
                data-page-length='10'>
                <thead>
                    <tr>
                        <th scope="col" class="text-start">User Type</th>
                        <th scope="col" class="text-start">Email</th>
                        <th scope="col" class="text-start">Password</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="text-start">employee</td>
                        <td class="text-start">employee@example.com</td>
                        <td class="text-start">15445@#AC</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </form>
</div>
<!-- Login Details sidebar end -->

<!-- Apply Leave sidebar start -->
<div
    class="apply-leave bg-white position-fixed end-0 top-0 h-100vh overflow-y-auto z-99 max-w-700-px w-100 translate-x-full duration-300 active-translate-0">
    <div class="px-20 py-12 border-bottom d-flex align-items-center justify-content-between gap-20">
        <h5 class="text-lg mb-0">Apply Leave</h5>
        <button type="button" class="close-apply-leave text-danger-600 text-lg d-flex">
            <i class="ri-close-large-line"></i>
        </button>
    </div>
    <form action="#" class="d-flex flex-column p-20">
        <div class="row g-3">
            <div class="col-sm-6">
                <div class="">
                    <label for="leaveType" class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Leave Type
                    </label>
                    <select id="leaveType" class="form-control form-select">
                        <option value="Select a leave type" selected disabled>Select a leave type</option>
                        <option value="Sickness">Sickness</option>
                        <option value="Accident">Accident</option>
                        <option value="Travel">Travel</option>
                    </select>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="">
                    <label for="fromDate" class="text-sm fw-semibold text-primary-light d-inline-block mb-8">From Date
                    </label>
                    <input type="date" class="form-control" id="fromDate">
                </div>
            </div>
            <div class="col-sm-6">
                <div class="">
                    <label for="toDate" class="text-sm fw-semibold text-primary-light d-inline-block mb-8">To Date
                    </label>
                    <input type="date" class="form-control" id="toDate">
                </div>
            </div>
            <div class="col-sm-6">
                <div class="">
                    <label for="leaveDays" class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Leave
                        Days</label>
                    <select id="leaveDays" class="form-control form-select">
                        <option value="Ex: Full day,  first half, second half">Ex: Full day, first half, second half
                        </option>
                        <option value="Ex: Full day,  first half, second half">Ex: Full day, first half, second half
                        </option>
                        <option value="Ex: Full day,  first half, second half">Ex: Full day, first half, second half
                        </option>
                        <option value="Ex: Full day,  first half, second half">Ex: Full day, first half, second half
                        </option>
                    </select>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="">
                    <label for="ReasonForLeave"
                        class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Reason for Leave
                    </label>
                    <textarea id="ReasonForLeave" class="form-control"
                        placeholder="Enter reason for leave..."></textarea>
                </div>
            </div>
            <div class="col-12">
                <div class="d-flex align-items-center justify-content-center gap-3 mt-8">
                    <button type="reset"
                        class="border border-danger-600 bg-hover-danger-200 text-danger-600 text-md px-50 py-11 radius-8">
                        Cancel
                    </button>
                    <button type="submit"
                        class="btn btn-primary-600 border border-primary-600 text-md px-28 py-12 radius-8">
                        Send Request
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>
<!-- Apply Leave sidebar end -->

<!-- Collect Fees sidebar start -->
<div
    class="collect-payroll bg-white position-fixed end-0 top-0 h-100vh overflow-y-auto z-99 max-w-700-px w-100 translate-x-full duration-300 active-translate-0">
    <div class="px-20 py-12 border-bottom d-flex align-items-center justify-content-between gap-20">
        <h5 class="text-lg mb-0">Collect Fees</h5>
        <button type="button" class="close-collect-payroll text-danger-600 text-lg d-flex">
            <i class="ri-close-large-line"></i>
        </button>
    </div>
    <form action="#" class="d-flex flex-column p-20">
        <div class="row g-3">
            <div class="col-sm-6">
                <div class="">
                    <label for="feesType" class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Leave Type
                    </label>
                    <select id="feesType" class="form-control form-select">
                        <option value="Select a fees type" selected disabled>Select a fees type</option>
                        <option value="May month fees">May month fees</option>
                        <option value="June month fees">June month fees</option>
                        <option value="July month fees">July month fees</option>
                        <option value="August month fees">August month fees</option>
                        <option value="September month fees">September month fees</option>
                        <option value="October month fees">October month fees</option>
                        <option value="November month fees">November month fees</option>
                    </select>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="">
                    <label for="feesDate" class="text-sm fw-semibold text-primary-light d-inline-block mb-8">From Date
                    </label>
                    <input type="date" class="form-control" id="feesDate">
                </div>
            </div>
            <div class="col-sm-6">
                <div class="">
                    <label for="feesAmount" class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Amount
                    </label>
                    <input type="text" class="form-control" id="feesAmount" value="$700.50" placeholder="$700.50"
                        disabled>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="">
                    <label for="feesPaymentType"
                        class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Payment Type</label>
                    <select id="feesPaymentType" class="form-control form-select">
                        <option value="Bank">Bank</option>
                        <option value="bKash">bKash</option>
                    </select>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="">
                    <label for="feesNote" class="text-sm fw-semibold text-primary-light d-inline-block mb-8">Reason for
                        Leave
                    </label>
                    <textarea id="feesNote" class="form-control" placeholder="Enter note..."></textarea>
                </div>
            </div>
            <div class="col-12">
                <div class="d-flex align-items-center justify-content-center gap-3 mt-8">
                    <button type="reset"
                        class="border border-danger-600 bg-hover-danger-200 text-danger-600 text-md px-50 py-11 radius-8">
                        Cancel
                    </button>
                    <button type="submit"
                        class="btn btn-primary-600 border border-primary-600 text-md px-28 py-12 radius-8">
                        Pay
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>
<!-- Collect Fees sidebar end -->

<!-- Modal Delete Event start -->
<div class="modal fade" id="exampleModalDelete" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-sm modal-dialog modal-dialog-centered max-w-340-px">
        <div class="modal-content radius-16 bg-base">
            <div class="modal-body pt-32 px-36 pb-24 text-center">
                <span class="mb-16 fs-1 line-height-1 text-danger">
                    <iconify-icon icon="fluent:delete-24-regular" class="menu-icon"></iconify-icon>
                </span>
                <h6 class="text-lg fw-semibold text-primary-light mb-0">Are your sure you want to Suspend this employee
                </h6>
                <div class="d-flex align-items-center justify-content-center gap-3 mt-24">
                    <button type="reset"
                        class="flex-grow-1 border border-danger-600 bg-hover-danger-200 text-danger-600 text-md px-24 py-11 radius-8">
                        Cancel
                    </button>
                    <button type="button"
                        class="flex-grow-1 btn btn-primary-600 border border-primary-600 text-md px-16 py-12 radius-8">
                        Yes, Suspend
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal Delete Event end -->

<!-- Payslip modal start -->
 <div class="modal fade" id="payslipModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-sm modal-dialog modal-dialog-centered max-w-600-px">
        <div class="modal-content radius-16 bg-base">
            <div class="modal-body p-24">
                <div class="text-center">
                    <h6 class="mb-0">School Name</h6>            
                    <p class="text-secondary-light">Smithbroand, Unit 4, Holler Tower, San Diego</p>
                </div>
                <div class="d-flex align-items-center justify-content-between gap-20 flex-wrap mt-24 ">
                    <div class="d-flex flex-column">
                        <div class="text-sm fw-medium d-flex">
                            <span class="text-primary-light w-110-px text-start">Invoice No</span>
                            <span class="text-primary-light">: #5695</span>
                        </div>
                        <div class="text-sm fw-medium d-flex">
                            <span class="text-primary-light w-110-px text-start">employee Name</span>
                            <span class="text-primary-light">: Jon Dan</span>
                        </div>
                        <div class="text-sm fw-medium d-flex">
                            <span class="text-primary-light w-110-px text-start">Phone</span>
                            <span class="text-primary-light">: +112515474</span>
                        </div>
                    </div>
                    <div class="d-flex flex-column">
                        <div class="text-sm fw-medium d-flex">
                            <span class="text-primary-light text-start">Payslip</span>
                        </div>
                        <div class="text-sm fw-medium d-flex">
                            <span class="text-secondary-light text-start">Month: January 2025</span>
                        </div>
                        <div class="text-sm fw-medium d-flex">
                            <span class="text-secondary-light text-start">Payment : 15 Jan 2025</span>
                        </div>
                    </div>
                </div>
                <ul class="border mt-24 radius-8 overflow-hidden">
                    <li class="py-10 px-20 d-flex align-items-center justify-content-between gap-20 bg-neutral-50 border-bottom">
                        <span class="text-primary-light fw-semibold">Name</span>
                        <span class="text-primary-light fw-semibold">Amount</span>
                    </li>
                    <li class="py-10 px-20 d-flex align-items-center justify-content-between gap-20 border-bottom">
                        <span class="text-primary-light">Base Salary</span>
                        <span class="text-primary-light">$2000</span>
                    </li>
                    <li class="py-10 px-20 d-flex align-items-center justify-content-between gap-20 border-bottom">
                        <span class="text-primary-light">Overtime Pay</span>
                        <span class="text-primary-light">$1000</span>
                    </li>
                    <li class="py-10 px-20 d-flex align-items-center justify-content-between gap-20 border-bottom">
                        <span class="text-primary-light">Bonuses</span>
                        <span class="text-primary-light">$2000</span>
                    </li>
                    <li class="py-10 px-20 d-flex align-items-center justify-content-between gap-20 border-bottom">
                        <span class="text-primary-light">Gross Salary</span>
                        <span class="text-primary-light">$5000</span>
                    </li>
                    <li class="py-10 px-20 d-flex align-items-center justify-content-between gap-20  bg-neutral-50">
                        <span class="text-primary-light fw-semibold text-lg">Total</span>
                        <span class="text-primary-light fw-semibold text-lg">$5000</span>
                    </li>
                </ul>
                <div class="pt-28 ms-16 text-start">
                    <p class="text-primary-light fw-medium mb-0">Payment type : Bank</p>
                </div>
                <div class="text-center mt-100-px">
                    <h6 class="text-xl mb-4">Thanks</h6>
                    <p class="text-secondary-light text-sm mb-0">If you need further assistance, please feel free to contact HR at <span class="fw-semibold text-primary-light">Example school</span> </p>
                </div>
                <div class="text-center mt-100-px">
                    <p class="text-secondary-light text-sm mb-0">Made by <span class="fw-semibold">Wowtheme7.</span> </p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Payslip modal end -->

  <!-- jQuery library js -->
  <script src="assets/js/lib/jquery-3.7.1.min.js"></script>
  <!-- Bootstrap js -->
  <script src="assets/js/lib/bootstrap.bundle.min.js"></script>
  <!-- Apex Chart js -->
  <script src="assets/js/lib/apexcharts.min.js"></script>
  <!-- Iconify Font js -->
  <script src="assets/js/lib/iconify-icon.min.js"></script>
  <!-- Data Table js -->
  <script src="assets/js/lib/dataTables.min.js"></script>
  
  <!-- jQuery UI js -->
  <script src="assets/js/lib/jquery-ui.min.js"></script>
  
  <!-- main js -->
  <script src="assets/js/app.js"></script>

<script>
    // Data Table start
    let table = new DataTable('#dataTable');
    let tableTwo = new DataTable('#dataTableTwo');
    let tableThree = new DataTable('#dataTableThree');
    let tableFour = new DataTable('#dataTableFour');
    let firstSemesterTable = new DataTable('#firstSemesterTable');
    let monthlyTestJun = new DataTable('#monthlyTestJun');
    let weeklyTestJun = new DataTable('#weeklyTestJun');
    let weeklyTestMay = new DataTable('#weeklyTestMay');
    let monthlyTestMay = new DataTable('#monthlyTestMay');
    let dataTableLibrary = new DataTable('#dataTableLibrary');
    let loginDetailsTable = new DataTable('#loginDetailsTable');

    // ✅ Data Table start
    $('.data-table').each(function () {
        const $table = $(this);
        const tableInstance = new DataTable(this);

        // Handle search input (inside same wrapper)
        $table.closest('.dataTable-wrapper').find('.dt-search .dt-input').on('keyup', function () {
            tableInstance.search(this.value).draw();
        });

        // Handle page length change (inside same wrapper)
        $table.closest('.dataTable-wrapper').find('.dt-length .dt-input').on('change', function () {
            const value = $(this).val();
            tableInstance.page.len(value).draw();
        });
    });
    // ✅ Data Table end

    // Dynamic Class added to the (absent/present/late/holiday)
    $(document).ready(function () {
        $('.attendance').each(function () {
            let value = $(this).text().trim().toUpperCase();

            if (value === 'P') {
                $(this).addClass('text-success-600')
            } else if (value === 'A') {
                $(this).addClass('text-danger-600')
            } else if (value === 'H') {
                $(this).addClass('text-warning-600')
            } else if (value === 'F') {
                $(this).addClass('text-purple-600')
            } else if (value === 'L') {
                $(this).addClass('text-info-600')
            }
        });
    });
    // Dynamic Class added to the (absent/present/late/holiday)


    // Custom accordion js start
    $(document).on('click', '.custom-accordion-btn', function () {
        $('.custom-accordion-btn').not(this).removeClass('active').siblings('.custom-accordion-content').slideUp();

        // Toggle current one
        $(this).toggleClass('active');
        $(this).siblings('.custom-accordion-content').slideToggle();
    });

    // Keep first accordion open by default
    $(document).ready(function () {
        const firstAccordion = $('.custom-accordion-btn').first();
        firstAccordion.addClass('active');
        firstAccordion.siblings('.custom-accordion-content').show();
    });
    // Custom accordion js end


    // Sidebar js start
    $('.my-sidebar-btn').on('click', function () {
        $('.my-sidebar').addClass('active');
        $('.overlay').addClass('active');
    });
    $('.close-my-sidebar, .overlay').on('click', function () {
        $('.my-sidebar').removeClass('active');
        $('.overlay').removeClass('active');
    });


    $('.apply-leave-btn').on('click', function () {
        $('.apply-leave').addClass('active');
        $('.overlay').addClass('active');
    });
    $('.close-apply-leave, .overlay').on('click', function () {
        $('.apply-leave').removeClass('active');
        $('.overlay').removeClass('active');
    });
    // Sidebar js end

    $('.collect-payroll-btn').on('click', function () {
        $('.collect-payroll').addClass('active');
        $('.overlay').addClass('active');
    });
    $('.close-collect-payroll, .overlay').on('click', function () {
        $('.collect-payroll').removeClass('active');
        $('.overlay').removeClass('active');
    });
    // Sidebar js end

</script>

</body>

</html>